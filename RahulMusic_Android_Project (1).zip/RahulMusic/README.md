# Rahul Music – Premium Offline Android Music Player

**Rahul Music** is a complete, 100% offline Android music player built with **Kotlin**, **Jetpack Compose (Material 3)**, **AndroidX Media3 (ExoPlayer + MediaSessionService)**, **NextLib FFmpeg Audio Decoder Extension**, **Room Database**, and **Jetpack DataStore**.

## Key Features
- **Signature Visual Identity**: Pitch-black (`#050507`), pure white (`#FFFFFF`), and vibrant crimson red (`#FF1744`) aesthetic with smooth animated transitions, adaptive vector icon, splash screen, Dark/Light themes, and 5 customizable accent presets.
- **Complete Offline Music Library**: Scans internal storage and removable SD cards via `MediaStore.Audio.Media` across all mounted volumes and supports direct directory mounting via the Android **Storage Access Framework (SAF)**.
- **Extensive Audio Format Support**: Hardware + FFmpeg (`NextRenderersFactory`) decoding for **MP3, FLAC, WAV, AAC, M4A, OGG, OPUS, WMA, AIFF, ALAC, APE, and WavPack (WV)**.
- **6 Library Views & Instant Search**: Browse by **Songs, Albums, Artists, Folders, Genres, and Custom Playlists**, plus **Favorites** and **Recently Played**, with sorting by Name, Duration, Date Modified, and Recently Added.
- **Full-Screen Now Playing & Lock-Screen MediaSession**: Background playback via `RahulMediaService` (`MediaSessionService`), lock-screen and notification transport controls, automatic pause on headphone/Bluetooth disconnect, and automatic restoration of the last played song, queue, and playback position.
- **Built-in Equalizer & DSP**: Multi-band hardware Equalizer, Bass Boost (`0..1000`), 3D Virtualizer (`0..1000`), custom stereo Left/Right `AudioBalanceProcessor` (`-1.0..+1.0`), pre-amp gain volume, playback speed (`0.5x..2.5x`), gapless playback, sleep timer, and synchronized `.lrc` / embedded `USLT` / Vorbis `LYRICS` display.

## How to Build & Install the APK
1. Open the `RahulMusic` folder in **Android Studio Ladybug (2024.2.1) or newer** with **JDK 17**.
2. Let Gradle sync dependencies from Google Maven, Maven Central, and JitPack.
3. Build a debug APK from terminal:
   ```bash
   ./gradlew assembleDebug
   ```
   The APK will be generated at `app/build/outputs/apk/debug/app-debug.apk`.
4. Install onto a connected Android device:
   ```bash
   adb install -r app/build/outputs/apk/debug/app-debug.apk
   ```
