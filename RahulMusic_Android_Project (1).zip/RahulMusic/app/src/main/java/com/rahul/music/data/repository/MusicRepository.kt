package com.rahul.music.data.repository

import android.net.Uri
import com.rahul.music.data.local.CustomLyricsEntity
import com.rahul.music.data.local.FavoriteEntity
import com.rahul.music.data.local.MusicDao
import com.rahul.music.data.local.PlaylistEntity
import com.rahul.music.data.local.PlaylistSongCrossRef
import com.rahul.music.data.local.PlaylistWithSongIds
import com.rahul.music.data.local.RecentHistoryEntity
import com.rahul.music.data.local.SafFolderEntity
import com.rahul.music.data.local.SongEntity
import com.rahul.music.data.model.LyricLine
import com.rahul.music.data.model.Song
import com.rahul.music.data.scanner.MediaStoreScanner
import com.rahul.music.utils.LrcLyricsParser
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext

data class UserPlaylist(
    val id: Long,
    val name: String,
    val songs: List<Song>
)

class MusicRepository(
    private val dao: MusicDao,
    private val scanner: MediaStoreScanner
) {

    val songsFlow: Flow<List<Song>> = dao.observeCachedSongs().map { list ->
        list.map { it.toDomainModel() }
    }

    val favoriteIdsFlow: Flow<Set<Long>> = dao.observeFavoriteSongIds().map { it.toSet() }

    val recentHistoryFlow: Flow<List<RecentHistoryEntity>> = dao.observeRecentHistory()

    val playlistsRawFlow: Flow<List<PlaylistWithSongIds>> = dao.observePlaylistsWithSongs()

    val safFoldersFlow: Flow<List<SafFolderEntity>> = dao.observeSafFolders()

    /**
     * Performs a full scan of MediaStore volumes + any user-attached SAF folders
     * and updates Room database cache for instant startup and smooth large-library scrolling.
     */
    suspend fun refreshMusicLibrary(): Int = withContext(Dispatchers.IO) {
        val mediaStoreSongs = scanner.scanAllMediaStoreVolumes()
        val safFolders = dao.observeSafFolders().first()
        val safSongs = safFolders.flatMap { folder ->
            runCatching { scanner.scanSafDirectoryTree(Uri.parse(folder.treeUriString)) }.getOrDefault(emptyList())
        }

        val combined = (mediaStoreSongs + safSongs).distinctBy { it.id }
        if (combined.isNotEmpty()) {
            dao.upsertSongs(combined)
            dao.pruneRemovedSongs(combined.map { it.id })
        } else {
            dao.clearAllSongs()
        }
        combined.size
    }

    suspend fun addSafFolderAndScan(treeUri: Uri, displayName: String): Int = withContext(Dispatchers.IO) {
        dao.addSafFolder(SafFolderEntity(treeUriString = treeUri.toString(), displayName = displayName))
        refreshMusicLibrary()
    }

    suspend fun toggleFavorite(songId: Long) = withContext(Dispatchers.IO) {
        if (dao.isFavorite(songId)) {
            dao.removeFavorite(songId)
        } else {
            dao.addFavorite(FavoriteEntity(songId = songId))
        }
    }

    suspend fun recordSongPlayed(songId: Long) = withContext(Dispatchers.IO) {
        val existing = dao.getRecentEntry(songId)
        val nextCount = (existing?.playCount ?: 0) + 1
        dao.upsertRecent(
            RecentHistoryEntity(
                songId = songId,
                playedAtMs = System.currentTimeMillis(),
                playCount = nextCount
            )
        )
    }

    suspend fun clearRecentHistory() = withContext(Dispatchers.IO) {
        dao.clearRecentHistory()
    }

    suspend fun createPlaylist(name: String): Long = withContext(Dispatchers.IO) {
        dao.createPlaylist(PlaylistEntity(name = name.trim()))
    }

    suspend fun renamePlaylist(playlistId: Long, newName: String) = withContext(Dispatchers.IO) {
        dao.renamePlaylist(playlistId, newName.trim())
    }

    suspend fun deletePlaylist(playlistId: Long) = withContext(Dispatchers.IO) {
        dao.deleteAllSongsFromPlaylist(playlistId)
        dao.deletePlaylist(playlistId)
    }

    suspend fun addSongToPlaylist(playlistId: Long, songId: Long) = withContext(Dispatchers.IO) {
        val nextOrder = dao.getMaxOrderInPlaylist(playlistId) + 1
        dao.addSongToPlaylist(
            PlaylistSongCrossRef(
                playlistId = playlistId,
                songId = songId,
                positionOrder = nextOrder
            )
        )
    }

    suspend fun removeSongFromPlaylist(playlistId: Long, songId: Long) = withContext(Dispatchers.IO) {
        dao.removeSongFromPlaylist(playlistId, songId)
    }

    suspend fun getLyricsForSong(song: Song): List<LyricLine> = withContext(Dispatchers.IO) {
        val custom = dao.getCustomLyrics(song.id)?.rawLrcContent
        LrcLyricsParser.loadLyricsForSong(song, custom)
    }

    suspend fun saveCustomLrcLyrics(songId: Long, rawLrc: String) = withContext(Dispatchers.IO) {
        dao.saveCustomLyrics(CustomLyricsEntity(songId = songId, rawLrcContent = rawLrc))
    }

    private fun SongEntity.toDomainModel(): Song = Song(
        id = id,
        title = title,
        artist = artist,
        artistId = artistId,
        album = album,
        albumId = albumId,
        duration = duration,
        uri = Uri.parse(uriString),
        albumArtUri = albumArtUriString?.let { Uri.parse(it) },
        path = path,
        folderName = folderName,
        folderPath = folderPath,
        genre = genre,
        mimeType = mimeType,
        sizeBytes = sizeBytes,
        bitrateKbps = bitrateKbps,
        sampleRateHz = sampleRateHz,
        dateAddedSec = dateAddedSec,
        dateModifiedSec = dateModifiedSec,
        trackNumber = trackNumber
    )
}
