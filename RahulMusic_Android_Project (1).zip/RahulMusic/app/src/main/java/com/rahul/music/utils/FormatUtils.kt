package com.rahul.music.utils

import java.util.Locale
import java.util.concurrent.TimeUnit

object FormatUtils {
    fun formatDuration(durationMs: Long): String {
        val safeMs = durationMs.coerceAtLeast(0L)
        val hours = TimeUnit.MILLISECONDS.toHours(safeMs)
        val minutes = TimeUnit.MILLISECONDS.toMinutes(safeMs) % 60
        val seconds = TimeUnit.MILLISECONDS.toSeconds(safeMs) % 60
        return if (hours > 0) {
            String.format(Locale.US, "%d:%02d:%02d", hours, minutes, seconds)
        } else {
            String.format(Locale.US, "%02d:%02d", minutes, seconds)
        }
    }

    fun formatFileSize(bytes: Long): String {
        if (bytes <= 0) return "0 MB"
        val mb = bytes / (1024.0 * 1024.0)
        return String.format(Locale.US, "%.1f MB", mb)
    }
}
