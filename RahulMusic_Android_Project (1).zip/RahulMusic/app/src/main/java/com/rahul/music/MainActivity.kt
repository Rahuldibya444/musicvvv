package com.rahul.music

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import com.rahul.music.ui.screens.RahulMusicScreen
import com.rahul.music.ui.theme.RahulMusicTheme
import com.rahul.music.ui.viewmodel.RahulViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: RahulViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            val settings by viewModel.settingsState.collectAsState()
            var hasPermission by remember { mutableStateOf(checkAudioPermission()) }

            val permissionLauncher = rememberLauncherForActivityResult(
                contract = ActivityResultContracts.RequestMultiplePermissions()
            ) { grants ->
                val audioGranted = grants[audioPermissionName()] == true || checkAudioPermission()
                hasPermission = audioGranted
                if (audioGranted) {
                    viewModel.scanMediaLibrary()
                }
            }

            val safTreeLauncher = rememberLauncherForActivityResult(
                contract = ActivityResultContracts.OpenDocumentTree()
            ) { treeUri: Uri? ->
                if (treeUri != null) {
                    runCatching {
                        contentResolver.takePersistableUriPermission(
                            treeUri,
                            Intent.FLAG_GRANT_READ_URI_PERMISSION
                        )
                    }
                    val folderLabel = treeUri.lastPathSegment?.substringAfterLast(':') ?: "Music Folder"
                    hasPermission = true
                    viewModel.addSafFolder(treeUri, folderLabel)
                }
            }

            LaunchedEffect(hasPermission) {
                if (hasPermission) {
                    viewModel.scanMediaLibrary()
                }
            }

            RahulMusicTheme(
                themeMode = settings.themeMode,
                accentPreset = settings.accentPreset
            ) {
                RahulMusicScreen(
                    viewModel = viewModel,
                    hasStoragePermission = hasPermission,
                    onRequestPermission = {
                        val permissionsToRequest = mutableListOf(audioPermissionName())
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                            permissionsToRequest.add(Manifest.permission.POST_NOTIFICATIONS)
                        }
                        permissionLauncher.launch(permissionsToRequest.toTypedArray())
                    },
                    onLaunchSafPicker = {
                        safTreeLauncher.launch(null)
                    }
                )
            }
        }
    }

    private fun audioPermissionName(): String {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            Manifest.permission.READ_MEDIA_AUDIO
        } else {
            Manifest.permission.READ_EXTERNAL_STORAGE
        }
    }

    private fun checkAudioPermission(): Boolean {
        return ContextCompat.checkSelfPermission(
            this,
            audioPermissionName()
        ) == PackageManager.PERMISSION_GRANTED
    }
}
