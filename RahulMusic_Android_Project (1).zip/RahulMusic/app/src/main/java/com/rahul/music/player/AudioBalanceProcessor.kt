package com.rahul.music.player

import androidx.media3.common.C
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.AudioProcessor.AudioFormat
import androidx.media3.common.audio.BaseAudioProcessor
import androidx.media3.common.util.UnstableApi
import java.nio.ByteBuffer
import kotlin.math.min

/**
 * Real-time stereo Left/Right channel balance (-1.0f = Full Left, 0.0f = Center, +1.0f = Full Right)
 * and smooth master volume scalar for 16-bit stereo PCM audio playback.
 */
@UnstableApi
class AudioBalanceProcessor : BaseAudioProcessor() {

    @Volatile
    private var balance: Float = 0.0f // -1.0f .. +1.0f

    @Volatile
    private var masterGain: Float = 1.0f // 0.0f .. 1.0f

    fun setBalanceAndGain(newBalance: Float, newGain: Float) {
        balance = newBalance.coerceIn(-1.0f, 1.0f)
        masterGain = newGain.coerceIn(0.0f, 1.0f)
    }

    override fun onConfigure(inputAudioFormat: AudioFormat): AudioFormat {
        return if (inputAudioFormat.encoding == C.ENCODING_PCM_16BIT && inputAudioFormat.channelCount == 2) {
            inputAudioFormat
        } else {
            AudioFormat.NOT_SET
        }
    }

    override fun queueInput(inputBuffer: ByteBuffer) {
        val remaining = inputBuffer.remaining()
        if (remaining == 0) return

        val bal = balance
        val gain = masterGain
        val leftMultiplier = min(1.0f, 1.0f - bal) * gain
        val rightMultiplier = min(1.0f, 1.0f + bal) * gain

        val outputBuffer = replaceOutputBuffer(remaining)
        while (inputBuffer.remaining() >= 4) {
            val leftSample = inputBuffer.short
            val rightSample = inputBuffer.short

            val scaledLeft = (leftSample * leftMultiplier).toInt().coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
            val scaledRight = (rightSample * rightMultiplier).toInt().coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()

            outputBuffer.putShort(scaledLeft)
            outputBuffer.putShort(scaledRight)
        }
        outputBuffer.flip()
    }
}
