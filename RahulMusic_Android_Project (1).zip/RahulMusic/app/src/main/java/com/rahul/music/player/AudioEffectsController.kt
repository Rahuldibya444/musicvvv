package com.rahul.music.player

import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.media.audiofx.Virtualizer
import com.rahul.music.data.model.EqualizerBandState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class AudioEffectsUiState(
    val isAvailable: Boolean = false,
    val isEnabled: Boolean = false,
    val presets: List<String> = listOf("Normal", "Classical", "Dance", "Flat", "Folk", "Heavy Metal", "Hip Hop", "Jazz", "Pop", "Rock"),
    val selectedPresetIndex: Int = 0,
    val bands: List<EqualizerBandState> = emptyList(),
    val bassBoostStrength: Int = 0, // 0..1000
    val virtualizerStrength: Int = 0 // 0..1000
)

class AudioEffectsController {

    private var equalizer: Equalizer? = null
    private var bassBoost: BassBoost? = null
    private var virtualizer: Virtualizer? = null
    private var currentSessionId: Int = 0

    private val _state = MutableStateFlow(AudioEffectsUiState())
    val state: StateFlow<AudioEffectsUiState> = _state.asStateFlow()

    fun bindToAudioSession(
        audioSessionId: Int,
        enabled: Boolean,
        presetIndex: Int,
        savedBandLevelsCsv: String,
        bassStrength: Int,
        virtualizerStrength: Int
    ) {
        if (audioSessionId <= 0) return
        if (currentSessionId == audioSessionId && equalizer != null) return

        release()
        currentSessionId = audioSessionId

        runCatching {
            val eq = Equalizer(0, audioSessionId).apply {
                this.enabled = enabled
            }
            val bb = runCatching {
                BassBoost(0, audioSessionId).apply {
                    this.enabled = enabled
                    if (strengthSupported) setStrength(bassStrength.toShort())
                }
            }.getOrNull()

            val virt = runCatching {
                Virtualizer(0, audioSessionId).apply {
                    this.enabled = enabled
                    if (strengthSupported) setStrength(virtualizerStrength.toShort())
                }
            }.getOrNull()

            val numBands = eq.numberOfBands
            val levelRange = eq.bandLevelRange
            val minMb = levelRange[0]
            val maxMb = levelRange[1]

            val presetNames = (0 until eq.numberOfPresets).map { idx ->
                eq.getPresetName(idx.toShort())
            }.ifEmpty {
                listOf("Normal", "Bass Extreme", "Vocal Clarity", "Rock", "Pop", "Electronic")
            }

            val savedLevels = savedBandLevelsCsv.split(",")
                .mapNotNull { it.trim().toShortOrNull() }

            if (savedLevels.size == numBands.toInt()) {
                for (i in 0 until numBands) {
                    eq.setBandLevel(i.toShort(), savedLevels[i].coerceIn(minMb, maxMb))
                }
            } else if (presetIndex in 0 until eq.numberOfPresets) {
                eq.usePreset(presetIndex.toShort())
            }

            equalizer = eq
            bassBoost = bb
            virtualizer = virt
            refreshState(enabled, presetIndex, bassStrength, virtualizerStrength, presetNames)
        }
    }

    fun setEnabled(enabled: Boolean) {
        runCatching {
            equalizer?.enabled = enabled
            bassBoost?.enabled = enabled
            virtualizer?.enabled = enabled
            _state.value = _state.value.copy(isEnabled = enabled)
        }
    }

    fun selectPreset(presetIndex: Int) {
        val eq = equalizer ?: return
        runCatching {
            if (presetIndex in 0 until eq.numberOfPresets) {
                eq.usePreset(presetIndex.toShort())
            }
            refreshState(
                enabled = _state.value.isEnabled,
                presetIndex = presetIndex,
                bassStrength = _state.value.bassBoostStrength,
                virtualizerStrength = _state.value.virtualizerStrength,
                presetNames = _state.value.presets
            )
        }
    }

    fun setBandLevel(bandIndex: Short, levelMb: Short) {
        val eq = equalizer ?: return
        runCatching {
            val range = eq.bandLevelRange
            val clamped = levelMb.coerceIn(range[0], range[1])
            eq.setBandLevel(bandIndex, clamped)
            refreshState(
                enabled = _state.value.isEnabled,
                presetIndex = -1,
                bassStrength = _state.value.bassBoostStrength,
                virtualizerStrength = _state.value.virtualizerStrength,
                presetNames = _state.value.presets
            )
        }
    }

    fun setBassBoost(strength: Int) {
        val clamped = strength.coerceIn(0, 1000)
        runCatching {
            bassBoost?.takeIf { it.strengthSupported }?.setStrength(clamped.toShort())
            _state.value = _state.value.copy(bassBoostStrength = clamped)
        }
    }

    fun setVirtualizer(strength: Int) {
        val clamped = strength.coerceIn(0, 1000)
        runCatching {
            virtualizer?.takeIf { it.strengthSupported }?.setStrength(clamped.toShort())
            _state.value = _state.value.copy(virtualizerStrength = clamped)
        }
    }

    private fun refreshState(
        enabled: Boolean,
        presetIndex: Int,
        bassStrength: Int,
        virtualizerStrength: Int,
        presetNames: List<String>
    ) {
        val eq = equalizer ?: return
        val range = eq.bandLevelRange
        val bands = (0 until eq.numberOfBands).map { i ->
            val b = i.toShort()
            EqualizerBandState(
                index = b,
                centerFreqHz = eq.getCenterFreq(b) / 1000,
                minLevelMb = range[0],
                maxLevelMb = range[1],
                currentLevelMb = eq.getBandLevel(b)
            )
        }
        _state.value = AudioEffectsUiState(
            isAvailable = true,
            isEnabled = enabled,
            presets = presetNames,
            selectedPresetIndex = presetIndex,
            bands = bands,
            bassBoostStrength = bassStrength,
            virtualizerStrength = virtualizerStrength
        )
    }

    fun release() {
        runCatching { equalizer?.release() }
        runCatching { bassBoost?.release() }
        runCatching { virtualizer?.release() }
        equalizer = null
        bassBoost = null
        virtualizer = null
    }
}
