package com.rahul.music.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowDownward
import androidx.compose.material.icons.rounded.ArrowUpward
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.rahul.music.data.model.AccentPreset
import com.rahul.music.data.model.Song
import com.rahul.music.data.model.ThemeMode
import com.rahul.music.data.preferences.PersistedSettings
import com.rahul.music.data.repository.UserPlaylist
import com.rahul.music.player.AudioEffectsUiState
import com.rahul.music.ui.viewmodel.PlayerUiState
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EqualizerBottomSheet(
    eqState: AudioEffectsUiState,
    onDismiss: () -> Unit,
    onToggleEnabled: (Boolean) -> Unit,
    onSelectPreset: (Int) -> Unit,
    onBandLevelChanged: (Short, Short) -> Unit,
    onBassBoostChanged: (Int) -> Unit,
    onVirtualizerChanged: (Int) -> Unit
) {
    val primary = MaterialTheme.colorScheme.primary
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = MaterialTheme.colorScheme.surface
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Built-in Equalizer & DSP",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Multi-band EQ, Bass Boost & 3D Virtualizer",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Switch(
                    checked = eqState.isEnabled,
                    onCheckedChange = onToggleEnabled
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Preset Selector Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                eqState.presets.forEachIndexed { idx, name ->
                    FilterChip(
                        selected = eqState.selectedPresetIndex == idx,
                        onClick = { onSelectPreset(idx) },
                        label = { Text(name) }
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Frequency Bands
            if (eqState.bands.isEmpty()) {
                Text(
                    text = "Start playing a song to activate live hardware equalizer bands.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(vertical = 12.dp)
                )
            } else {
                eqState.bands.forEach { band ->
                    val freqLabel = if (band.centerFreqHz >= 1000) {
                        String.format(Locale.US, "%.1f kHz", band.centerFreqHz / 1000f)
                    } else {
                        "${band.centerFreqHz} Hz"
                    }
                    val dbValue = band.currentLevelMb / 100f
                    Column(modifier = Modifier.fillMaxWidth()) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(text = freqLabel, style = MaterialTheme.typography.labelMedium)
                            Text(
                                text = String.format(Locale.US, "%+.1f dB", dbValue),
                                style = MaterialTheme.typography.labelMedium,
                                color = primary
                            )
                        }
                        Slider(
                            value = band.currentLevelMb.toFloat(),
                            onValueChange = { onBandLevelChanged(band.index, it.toInt().toShort()) },
                            valueRange = band.minLevelMb.toFloat()..band.maxLevelMb.toFloat(),
                            enabled = eqState.isEnabled
                        )
                    }
                }
            }

            HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

            // Bass Boost
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("Bass Boost", style = MaterialTheme.typography.titleMedium)
                Text("${eqState.bassBoostStrength / 10}%", color = primary)
            }
            Slider(
                value = eqState.bassBoostStrength.toFloat(),
                onValueChange = { onBassBoostChanged(it.toInt()) },
                valueRange = 0f..1000f,
                enabled = eqState.isEnabled
            )

            // Virtualizer
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("3D Spatial Virtualizer", style = MaterialTheme.typography.titleMedium)
                Text("${eqState.virtualizerStrength / 10}%", color = primary)
            }
            Slider(
                value = eqState.virtualizerStrength.toFloat(),
                onValueChange = { onVirtualizerChanged(it.toInt()) },
                valueRange = 0f..1000f,
                enabled = eqState.isEnabled
            )

            Spacer(modifier = Modifier.height(20.dp))
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SpeedAndBalanceBottomSheet(
    playerState: PlayerUiState,
    onDismiss: () -> Unit,
    onSpeedChanged: (Float) -> Unit,
    onBalanceAndVolumeChanged: (Float, Float) -> Unit,
    onGaplessChanged: (Boolean) -> Unit
) {
    val primary = MaterialTheme.colorScheme.primary
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = MaterialTheme.colorScheme.surface
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 12.dp)
        ) {
            Text(
                text = "Playback Speed, Stereo Balance & Volume",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(16.dp))

            // Playback Speed
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Playback Speed", style = MaterialTheme.typography.titleMedium)
                Text(
                    text = String.format(Locale.US, "%.2fx", playerState.playbackSpeed),
                    color = primary,
                    fontWeight = FontWeight.Bold
                )
            }
            Slider(
                value = playerState.playbackSpeed,
                onValueChange = onSpeedChanged,
                valueRange = 0.5f..2.5f
            )
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                listOf(0.75f, 1.0f, 1.25f, 1.5f, 2.0f).forEach { preset ->
                    FilterChip(
                        selected = kotlin.math.abs(playerState.playbackSpeed - preset) < 0.03f,
                        onClick = { onSpeedChanged(preset) },
                        label = { Text("${preset}x") }
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Stereo Left/Right Balance
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("Audio Balance (L / R)", style = MaterialTheme.typography.titleMedium)
                val balText = when {
                    kotlin.math.abs(playerState.audioBalance) < 0.05f -> "Center"
                    playerState.audioBalance < 0f -> String.format(Locale.US, "Left %d%%", (-playerState.audioBalance * 100).toInt())
                    else -> String.format(Locale.US, "Right %d%%", (playerState.audioBalance * 100).toInt())
                }
                Text(balText, color = primary, fontWeight = FontWeight.Bold)
            }
            Slider(
                value = playerState.audioBalance,
                onValueChange = { onBalanceAndVolumeChanged(it, playerState.masterVolume) },
                valueRange = -1.0f..1.0f
            )
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End
            ) {
                TextButton(onClick = { onBalanceAndVolumeChanged(0.0f, playerState.masterVolume) }) {
                    Text("Reset Balance to Center")
                }
            }

            // Pre-amp Master Volume Gain
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("Player Gain Volume", style = MaterialTheme.typography.titleMedium)
                Text("${(playerState.masterVolume * 100).toInt()}%", color = primary, fontWeight = FontWeight.Bold)
            }
            Slider(
                value = playerState.masterVolume,
                onValueChange = { onBalanceAndVolumeChanged(playerState.audioBalance, it) },
                valueRange = 0.1f..1.0f
            )

            HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

            // Gapless Playback Toggle
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("Gapless Playback", style = MaterialTheme.typography.titleMedium)
                    Text(
                        "Seamless transitions between consecutive album tracks",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Switch(
                    checked = playerState.gaplessPlayback,
                    onCheckedChange = onGaplessChanged
                )
            }

            Spacer(modifier = Modifier.height(20.dp))
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun QueueBottomSheet(
    playerState: PlayerUiState,
    onDismiss: () -> Unit,
    onJumpToIndex: (Int) -> Unit,
    onMoveItem: (Int, Int) -> Unit,
    onRemoveItem: (Int) -> Unit
) {
    val primary = MaterialTheme.colorScheme.primary
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = MaterialTheme.colorScheme.surface
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(max = 520.dp)
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Playback Queue (${playerState.queue.size})",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Rounded.Close, contentDescription = "Close Queue")
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                itemsIndexed(playerState.queue, key = { idx, s -> "${s.id}_$idx" }) { index, song ->
                    val isCurrent = index == playerState.currentQueueIndex
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(
                                if (isCurrent) primary.copy(alpha = 0.16f)
                                else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                            )
                            .clickable { onJumpToIndex(index) }
                            .padding(horizontal = 12.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (isCurrent) {
                            Icon(
                                imageVector = Icons.Rounded.GraphicEq,
                                contentDescription = null,
                                tint = primary,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = song.title,
                                style = MaterialTheme.typography.titleMedium,
                                color = if (isCurrent) primary else MaterialTheme.colorScheme.onSurface,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = song.artist,
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        IconButton(
                            onClick = { if (index > 0) onMoveItem(index, index - 1) },
                            enabled = index > 0
                        ) {
                            Icon(Icons.Rounded.ArrowUpward, contentDescription = "Move Up", modifier = Modifier.size(18.dp))
                        }
                        IconButton(
                            onClick = { if (index < playerState.queue.lastIndex) onMoveItem(index, index + 1) },
                            enabled = index < playerState.queue.lastIndex
                        ) {
                            Icon(Icons.Rounded.ArrowDownward, contentDescription = "Move Down", modifier = Modifier.size(18.dp))
                        }
                        IconButton(onClick = { onRemoveItem(index) }) {
                            Icon(Icons.Rounded.DeleteOutline, contentDescription = "Remove from Queue", modifier = Modifier.size(18.dp))
                        }
                    }
                }
            }
            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}

@Composable
fun SleepTimerDialog(
    remainingSec: Long,
    onDismiss: () -> Unit,
    onSetMinutes: (Int) -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Sleep Timer") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (remainingSec > 0) {
                    Text(
                        text = "Active countdown: ${remainingSec / 60}m ${remainingSec % 60}s remaining",
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.Bold
                    )
                } else {
                    Text("Automatically pause playback after a selected duration:")
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf(15, 30, 45).forEach { mins ->
                        OutlinedButton(
                            onClick = {
                                onSetMinutes(mins)
                                onDismiss()
                            },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("${mins}m")
                        }
                    }
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf(60, 90, 120).forEach { mins ->
                        OutlinedButton(
                            onClick = {
                                onSetMinutes(mins)
                                onDismiss()
                            },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("${mins}m")
                        }
                    }
                }
            }
        },
        confirmButton = {
            if (remainingSec > 0) {
                TextButton(
                    onClick = {
                        onSetMinutes(0)
                        onDismiss()
                    }
                ) {
                    Text("Turn Off Timer", color = MaterialTheme.colorScheme.primary)
                }
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Close")
            }
        }
    )
}

@Composable
fun ThemeCustomizationDialog(
    settings: PersistedSettings,
    onDismiss: () -> Unit,
    onSelectTheme: (ThemeMode) -> Unit,
    onSelectAccent: (AccentPreset) -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Appearance & Accent Theme") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Theme Mode", style = MaterialTheme.typography.titleMedium)
                ThemeMode.entries.forEach { mode ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .clickable { onSelectTheme(mode) }
                            .padding(vertical = 8.dp, horizontal = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(mode.label)
                        if (settings.themeMode == mode) {
                            Text("Active", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                HorizontalDivider()
                Text("Accent Color", style = MaterialTheme.typography.titleMedium)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    AccentPreset.entries.forEach { preset ->
                        val swatchColor = Color(preset.hexColor)
                        val isSelected = settings.accentPreset == preset
                        Box(
                            modifier = Modifier
                                .size(42.dp)
                                .clip(CircleShape)
                                .background(swatchColor)
                                .border(
                                    width = if (isSelected) 3.dp else 1.dp,
                                    color = if (isSelected) MaterialTheme.colorScheme.onSurface else Color.Gray,
                                    shape = CircleShape
                                )
                                .clickable { onSelectAccent(preset) }
                        )
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Done")
            }
        }
    )
}

@Composable
fun AddToPlaylistDialog(
    song: Song,
    playlists: List<UserPlaylist>,
    onDismiss: () -> Unit,
    onCreateNewPlaylist: (String) -> Unit,
    onAddSongToPlaylist: (Long, Long) -> Unit
) {
    var newPlaylistName by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add to Playlist") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = song.title,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.primary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = newPlaylistName,
                        onValueChange = { newPlaylistName = it },
                        placeholder = { Text("New playlist name...") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    Button(
                        onClick = {
                            if (newPlaylistName.isNotBlank()) {
                                onCreateNewPlaylist(newPlaylistName)
                                newPlaylistName = ""
                            }
                        }
                    ) {
                        Text("Create")
                    }
                }

                if (playlists.isNotEmpty()) {
                    HorizontalDivider()
                    LazyColumn(modifier = Modifier.heightIn(max = 220.dp)) {
                        items(playlists) { pl ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .clickable {
                                        onAddSongToPlaylist(pl.id, song.id)
                                        onDismiss()
                                    }
                                    .padding(vertical = 10.dp, horizontal = 8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(pl.name, fontWeight = FontWeight.SemiBold)
                                Text("${pl.songs.size} songs", color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Close")
            }
        }
    )
}

@Composable
fun LyricsEditorDialog(
    songTitle: String,
    initialLrc: String,
    onDismiss: () -> Unit,
    onSaveLrc: (String) -> Unit
) {
    var lrcText by remember { mutableStateOf(initialLrc) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Synchronized LRC Lyrics") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "Paste [mm:ss.xx] synchronized LRC lines or plain lyrics for "$songTitle":",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                OutlinedTextField(
                    value = lrcText,
                    onValueChange = { lrcText = it },
                    placeholder = {
                        Text("[00:12.50] First lyric line...
[00:16.80] Second lyric line...")
                    },
                    minLines = 6,
                    maxLines = 12,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onSaveLrc(lrcText)
                    onDismiss()
                }
            ) {
                Text("Save Lyrics")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
