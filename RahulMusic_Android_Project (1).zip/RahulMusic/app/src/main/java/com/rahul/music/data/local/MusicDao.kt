package com.rahul.music.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import kotlinx.coroutines.flow.Flow

@Dao
interface MusicDao {

    // Cached Library Songs
    @Query("SELECT * FROM cached_songs")
    fun observeCachedSongs(): Flow<List<SongEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertSongs(songs: List<SongEntity>)

    @Query("DELETE FROM cached_songs WHERE id NOT IN (:validIds)")
    suspend fun pruneRemovedSongs(validIds: List<Long>)

    @Query("DELETE FROM cached_songs")
    suspend fun clearAllSongs()

    // Favorites
    @Query("SELECT songId FROM favorites ORDER BY addedAtMs DESC")
    fun observeFavoriteSongIds(): Flow<List<Long>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun addFavorite(entity: FavoriteEntity)

    @Query("DELETE FROM favorites WHERE songId = :songId")
    suspend fun removeFavorite(songId: Long)

    @Query("SELECT EXISTS(SELECT 1 FROM favorites WHERE songId = :songId)")
    suspend fun isFavorite(songId: Long): Boolean

    // Recently Played
    @Query("SELECT * FROM recent_history ORDER BY playedAtMs DESC LIMIT 100")
    fun observeRecentHistory(): Flow<List<RecentHistoryEntity>>

    @Query("SELECT * FROM recent_history WHERE songId = :songId LIMIT 1")
    suspend fun getRecentEntry(songId: Long): RecentHistoryEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertRecent(entity: RecentHistoryEntity)

    @Query("DELETE FROM recent_history")
    suspend fun clearRecentHistory()

    // Custom Playlists
    @Transaction
    @Query("SELECT * FROM playlists ORDER BY createdAtMs DESC")
    fun observePlaylistsWithSongs(): Flow<List<PlaylistWithSongIds>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun createPlaylist(playlist: PlaylistEntity): Long

    @Query("UPDATE playlists SET name = :newName WHERE playlistId = :playlistId")
    suspend fun renamePlaylist(playlistId: Long, newName: String)

    @Query("DELETE FROM playlists WHERE playlistId = :playlistId")
    suspend fun deletePlaylist(playlistId: Long)

    @Query("DELETE FROM playlist_songs WHERE playlistId = :playlistId")
    suspend fun deleteAllSongsFromPlaylist(playlistId: Long)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun addSongToPlaylist(ref: PlaylistSongCrossRef)

    @Query("DELETE FROM playlist_songs WHERE playlistId = :playlistId AND songId = :songId")
    suspend fun removeSongFromPlaylist(playlistId: Long, songId: Long)

    @Query("SELECT COALESCE(MAX(positionOrder), 0) FROM playlist_songs WHERE playlistId = :playlistId")
    suspend fun getMaxOrderInPlaylist(playlistId: Long): Int

    // Storage Access Framework (SAF) Imported Folders
    @Query("SELECT * FROM saf_folders ORDER BY addedAtMs DESC")
    fun observeSafFolders(): Flow<List<SafFolderEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun addSafFolder(entity: SafFolderEntity)

    @Query("DELETE FROM saf_folders WHERE treeUriString = :uriString")
    suspend fun removeSafFolder(uriString: String)

    // Custom / Imported LRC Lyrics
    @Query("SELECT * FROM custom_lyrics WHERE songId = :songId LIMIT 1")
    suspend fun getCustomLyrics(songId: Long): CustomLyricsEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveCustomLyrics(entity: CustomLyricsEntity)
}
