package com.rahul.music.ui.viewmodel

import android.app.Application
import android.content.ComponentName
import android.net.Uri
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import com.rahul.music.RahulMusicApp
import com.rahul.music.data.model.AccentPreset
import com.rahul.music.data.model.Album
import com.rahul.music.data.model.Artist
import com.rahul.music.data.model.GenreGroup
import com.rahul.music.data.model.LibraryTab
import com.rahul.music.data.model.LyricLine
import com.rahul.music.data.model.MusicFolder
import com.rahul.music.data.model.Song
import com.rahul.music.data.model.SortOption
import com.rahul.music.data.model.ThemeMode
import com.rahul.music.data.preferences.PersistedSettings
import com.rahul.music.data.repository.UserPlaylist
import com.rahul.music.player.AudioEffectsUiState
import com.rahul.music.player.RahulMediaService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class LibraryUiState(
    val isScanning: Boolean = false,
    val allSongs: List<Song> = emptyList(),
    val filteredSongs: List<Song> = emptyList(),
    val albums: List<Album> = emptyList(),
    val artists: List<Artist> = emptyList(),
    val folders: List<MusicFolder> = emptyList(),
    val genres: List<GenreGroup> = emptyList(),
    val playlists: List<UserPlaylist> = emptyList(),
    val favoriteSongs: List<Song> = emptyList(),
    val favoriteIds: Set<Long> = emptySet(),
    val recentlyPlayedSongs: List<Song> = emptyList(),
    val searchQuery: String = "",
    val selectedTab: LibraryTab = LibraryTab.SONGS,
    val sortOption: SortOption = SortOption.TITLE_ASC
)

data class PlayerUiState(
    val currentSong: Song? = null,
    val queue: List<Song> = emptyList(),
    val currentQueueIndex: Int = 0,
    val isPlaying: Boolean = false,
    val currentPositionMs: Long = 0L,
    val durationMs: Long = 0L,
    val shuffleEnabled: Boolean = false,
    val repeatMode: Int = Player.REPEAT_MODE_OFF,
    val playbackSpeed: Float = 1.0f,
    val playbackPitch: Float = 1.0f,
    val audioBalance: Float = 0.0f,
    val masterVolume: Float = 1.0f,
    val gaplessPlayback: Boolean = true,
    val lyrics: List<LyricLine> = emptyList(),
    val activeLyricIndex: Int = -1,
    val sleepTimerRemainingSec: Long = 0L
)

class RahulViewModel(application: Application) : AndroidViewModel(application) {

    private val app = application as RahulMusicApp
    private val repository = app.musicRepository
    private val prefsRepo = app.preferencesRepository
    val audioEffectsController = app.audioEffectsController

    private var controllerFuture: ListenableFuture<MediaController>? = null
    private var mediaController: MediaController? = null

    private val _isScanning = MutableStateFlow(false)
    private val _searchQuery = MutableStateFlow("")
    private val _selectedTab = MutableStateFlow(LibraryTab.SONGS)

    private val _playerState = MutableStateFlow(PlayerUiState())
    val playerState: StateFlow<PlayerUiState> = _playerState.asStateFlow()

    val equalizerState: StateFlow<AudioEffectsUiState> = audioEffectsController.state

    val settingsState: StateFlow<PersistedSettings> = prefsRepo.settingsFlow.stateIn(
        viewModelScope,
        SharingStarted.Eagerly,
        PersistedSettings()
    )

    private var sleepTimerJob: Job? = null
    private var hasRestoredSession = false

    val libraryState: StateFlow<LibraryUiState> = combine(
        repository.songsFlow,
        repository.favoriteIdsFlow,
        repository.recentHistoryFlow,
        repository.playlistsRawFlow,
        _isScanning,
        _searchQuery,
        _selectedTab,
        settingsState
    ) { values ->
        @Suppress("UNCHECKED_CAST")
        val rawSongs = values[0] as List<Song>
        @Suppress("UNCHECKED_CAST")
        val favIds = values[1] as Set<Long>
        @Suppress("UNCHECKED_CAST")
        val recentEntities = values[2] as List<com.rahul.music.data.local.RecentHistoryEntity>
        @Suppress("UNCHECKED_CAST")
        val rawPlaylists = values[3] as List<com.rahul.music.data.local.PlaylistWithSongIds>
        val scanning = values[4] as Boolean
        val query = values[5] as String
        val tab = values[6] as LibraryTab
        val prefs = values[7] as PersistedSettings

        withContext(Dispatchers.Default) {
            val songById = rawSongs.associateBy { it.id }
            val sortedSongs = sortSongs(rawSongs, prefs.sortOption)
            val filtered = if (query.isBlank()) {
                sortedSongs
            } else {
                val q = query.trim().lowercase()
                sortedSongs.filter {
                    it.title.lowercase().contains(q) ||
                        it.artist.lowercase().contains(q) ||
                        it.album.lowercase().contains(q) ||
                        it.folderName.lowercase().contains(q) ||
                        it.genre.lowercase().contains(q)
                }
            }

            val albums = sortedSongs.groupBy { it.albumId }.map { (albumId, list) ->
                val first = list.first()
                Album(
                    id = albumId,
                    name = first.album,
                    artist = first.artist,
                    albumArtUri = first.albumArtUri,
                    songCount = list.size,
                    year = 0,
                    songs = list.sortedBy { it.trackNumber }
                )
            }.sortedBy { it.name.lowercase() }

            val artists = sortedSongs.groupBy { it.artist.lowercase() }.map { (_, list) ->
                val first = list.first()
                Artist(
                    id = first.artistId,
                    name = first.artist,
                    songCount = list.size,
                    albumCount = list.map { it.albumId }.distinct().size,
                    artworkUri = first.albumArtUri,
                    songs = list
                )
            }.sortedBy { it.name.lowercase() }

            val folders = sortedSongs.groupBy { it.folderPath }.map { (path, list) ->
                val first = list.first()
                MusicFolder(
                    path = path,
                    name = first.folderName,
                    songCount = list.size,
                    isSafTree = path.startsWith("SAF:"),
                    songs = list
                )
            }.sortedBy { it.name.lowercase() }

            val genres = sortedSongs.groupBy { it.genre.lowercase() }.map { (_, list) ->
                val first = list.first()
                GenreGroup(
                    name = first.genre,
                    songCount = list.size,
                    songs = list
                )
            }.sortedBy { it.name.lowercase() }

            val playlists = rawPlaylists.map { pl ->
                val orderedSongs = pl.refs
                    .sortedBy { it.positionOrder }
                    .mapNotNull { songById[it.songId] }
                UserPlaylist(
                    id = pl.playlist.playlistId,
                    name = pl.playlist.name,
                    songs = orderedSongs
                )
            }

            val favSongs = sortedSongs.filter { it.id in favIds }
            val recentSongs = recentEntities.mapNotNull { songById[it.songId] }

            LibraryUiState(
                isScanning = scanning,
                allSongs = sortedSongs,
                filteredSongs = filtered,
                albums = albums,
                artists = artists,
                folders = folders,
                genres = genres,
                playlists = playlists,
                favoriteSongs = favSongs,
                favoriteIds = favIds,
                recentlyPlayedSongs = recentSongs,
                searchQuery = query,
                selectedTab = tab,
                sortOption = prefs.sortOption
            )
        }
    }.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        LibraryUiState()
    )

    init {
        connectToMediaService()
        startPositionProgressLoop()
    }

    private fun connectToMediaService() {
        val sessionToken = SessionToken(app, ComponentName(app, RahulMediaService::class.java))
        val future = MediaController.Builder(app, sessionToken).buildAsync()
        controllerFuture = future
        future.addListener(
            {
                val controller = runCatching { future.get() }.getOrNull() ?: return@addListener
                mediaController = controller
                setupControllerListener(controller)
                restorePlaybackSessionIfNeeded(controller)
            },
            ContextCompat.getMainExecutor(app)
        )
    }

    private fun setupControllerListener(controller: MediaController) {
        controller.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                _playerState.value = _playerState.value.copy(isPlaying = isPlaying)
                if (!isPlaying) {
                    persistCurrentPlaybackPosition()
                }
            }

            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                val songId = mediaItem?.mediaId?.toLongOrNull() ?: return
                val allSongs = libraryState.value.allSongs
                val song = allSongs.find { it.id == songId } ?: _playerState.value.queue.find { it.id == songId }
                if (song != null) {
                    _playerState.value = _playerState.value.copy(
                        currentSong = song,
                        currentQueueIndex = controller.currentMediaItemIndex,
                        durationMs = controller.duration.coerceAtLeast(song.duration)
                    )
                    viewModelScope.launch {
                        repository.recordSongPlayed(song.id)
                        val loadedLyrics = repository.getLyricsForSong(song)
                        _playerState.value = _playerState.value.copy(
                            lyrics = loadedLyrics,
                            activeLyricIndex = -1
                        )
                        persistCurrentPlaybackPosition()
                    }
                }
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_READY) {
                    _playerState.value = _playerState.value.copy(
                        durationMs = controller.duration.coerceAtLeast(_playerState.value.currentSong?.duration ?: 0L)
                    )
                }
            }

            override fun onShuffleModeEnabledChanged(shuffleModeEnabled: Boolean) {
                _playerState.value = _playerState.value.copy(shuffleEnabled = shuffleModeEnabled)
            }

            override fun onRepeatModeChanged(repeatMode: Int) {
                _playerState.value = _playerState.value.copy(repeatMode = repeatMode)
            }
        })
    }

    private fun restorePlaybackSessionIfNeeded(controller: MediaController) {
        if (hasRestoredSession) return
        viewModelScope.launch {
            val prefs = prefsRepo.settingsFlow.first()
            val allSongs = repository.songsFlow.first()
            if (allSongs.isEmpty()) return@launch
            hasRestoredSession = true

            // Restore speed, pitch, shuffle, repeat, balance
            controller.shuffleModeEnabled = prefs.shuffleEnabled
            controller.repeatMode = prefs.repeatMode
            controller.playbackParameters = PlaybackParameters(prefs.playbackSpeed, prefs.playbackPitch)
            app.balanceProcessor.setBalanceAndGain(prefs.audioBalance, prefs.masterVolume)

            _playerState.value = _playerState.value.copy(
                shuffleEnabled = prefs.shuffleEnabled,
                repeatMode = prefs.repeatMode,
                playbackSpeed = prefs.playbackSpeed,
                playbackPitch = prefs.playbackPitch,
                audioBalance = prefs.audioBalance,
                masterVolume = prefs.masterVolume,
                gaplessPlayback = prefs.gaplessPlayback
            )

            // If service is already playing something, sync state from it
            if (controller.mediaItemCount > 0) {
                val activeId = controller.currentMediaItem?.mediaId?.toLongOrNull()
                val currentSong = allSongs.find { it.id == activeId } ?: allSongs.first()
                val loadedLyrics = repository.getLyricsForSong(currentSong)
                _playerState.value = _playerState.value.copy(
                    currentSong = currentSong,
                    queue = allSongs,
                    currentQueueIndex = controller.currentMediaItemIndex,
                    isPlaying = controller.isPlaying,
                    currentPositionMs = controller.currentPosition,
                    durationMs = controller.duration.coerceAtLeast(currentSong.duration),
                    lyrics = loadedLyrics
                )
                return@launch
            }

            // Otherwise restore last queue and last song position without auto-starting playback
            val songById = allSongs.associateBy { it.id }
            val restoredQueue = prefs.lastQueueIdsCsv.split(",")
                .mapNotNull { it.trim().toLongOrNull() }
                .mapNotNull { songById[it] }
                .ifEmpty { allSongs }

            val targetSong = restoredQueue.find { it.id == prefs.lastPlayedSongId } ?: restoredQueue.first()
            val targetIndex = restoredQueue.indexOfFirst { it.id == targetSong.id }.coerceAtLeast(0)
            val mediaItems = restoredQueue.map { it.toMediaItem() }

            controller.setMediaItems(mediaItems, targetIndex, prefs.lastPlaybackPositionMs.coerceAtLeast(0L))
            controller.prepare()
            controller.pause()

            val loadedLyrics = repository.getLyricsForSong(targetSong)
            _playerState.value = _playerState.value.copy(
                currentSong = targetSong,
                queue = restoredQueue,
                currentQueueIndex = targetIndex,
                isPlaying = false,
                currentPositionMs = prefs.lastPlaybackPositionMs.coerceAtLeast(0L),
                durationMs = targetSong.duration,
                lyrics = loadedLyrics
            )
        }
    }

    private fun startPositionProgressLoop() {
        viewModelScope.launch {
            var tickCounter = 0
            while (isActive) {
                val controller = mediaController
                if (controller != null && controller.isPlaying) {
                    val pos = controller.currentPosition.coerceAtLeast(0L)
                    val dur = controller.duration.coerceAtLeast(_playerState.value.currentSong?.duration ?: 0L)
                    val lyrics = _playerState.value.lyrics
                    val activeIdx = if (lyrics.isNotEmpty()) {
                        lyrics.indexOfLast { it.timestampMs <= pos }
                    } else -1

                    _playerState.value = _playerState.value.copy(
                        currentPositionMs = pos,
                        durationMs = dur,
                        activeLyricIndex = activeIdx
                    )

                    tickCounter++
                    if (tickCounter % 10 == 0) {
                        persistCurrentPlaybackPosition()
                    }
                }
                delay(200L)
            }
        }
    }

    private fun persistCurrentPlaybackPosition() {
        val state = _playerState.value
        val currentSong = state.currentSong ?: return
        val pos = mediaController?.currentPosition ?: state.currentPositionMs
        val queueIds = state.queue.map { it.id }
        viewModelScope.launch {
            prefsRepo.saveLastPlaybackState(currentSong.id, pos, queueIds)
        }
    }

    fun scanMediaLibrary() {
        if (_isScanning.value) return
        viewModelScope.launch {
            _isScanning.value = true
            repository.refreshMusicLibrary()
            _isScanning.value = false
            mediaController?.let { restorePlaybackSessionIfNeeded(it) }
        }
    }

    fun addSafFolder(treeUri: Uri, label: String) {
        viewModelScope.launch {
            _isScanning.value = true
            repository.addSafFolderAndScan(treeUri, label)
            _isScanning.value = false
        }
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun selectTab(tab: LibraryTab) {
        _selectedTab.value = tab
    }

    fun setSortOption(option: SortOption) {
        viewModelScope.launch {
            prefsRepo.setSortOption(option)
        }
    }

    fun playSongList(songs: List<Song>, startIndex: Int = 0) {
        if (songs.isEmpty()) return
        val controller = mediaController ?: return
        val safeIndex = startIndex.coerceIn(0, songs.lastIndex)
        val selectedSong = songs[safeIndex]

        val mediaItems = songs.map { it.toMediaItem() }
        controller.setMediaItems(mediaItems, safeIndex, 0L)
        controller.prepare()
        controller.play()

        viewModelScope.launch {
            val loadedLyrics = repository.getLyricsForSong(selectedSong)
            _playerState.value = _playerState.value.copy(
                currentSong = selectedSong,
                queue = songs,
                currentQueueIndex = safeIndex,
                isPlaying = true,
                currentPositionMs = 0L,
                durationMs = selectedSong.duration,
                lyrics = loadedLyrics,
                activeLyricIndex = -1
            )
            repository.recordSongPlayed(selectedSong.id)
            persistCurrentPlaybackPosition()
        }
    }

    fun togglePlayPause() {
        val controller = mediaController ?: return
        if (controller.isPlaying) {
            controller.pause()
        } else {
            if (controller.mediaItemCount == 0 && libraryState.value.allSongs.isNotEmpty()) {
                playSongList(libraryState.value.allSongs, 0)
            } else {
                controller.play()
            }
        }
    }

    fun skipToNext() {
        val controller = mediaController ?: return
        if (controller.hasNextMediaItem()) {
            controller.seekToNextMediaItem()
        } else if (controller.mediaItemCount > 0) {
            controller.seekTo(0, 0L)
        }
    }

    fun skipToPrevious() {
        val controller = mediaController ?: return
        if (controller.currentPosition > 3500L) {
            controller.seekTo(0L)
        } else if (controller.hasPreviousMediaItem()) {
            controller.seekToPreviousMediaItem()
        } else if (controller.mediaItemCount > 0) {
            controller.seekTo(controller.mediaItemCount - 1, 0L)
        }
    }

    fun seekToPosition(positionMs: Long) {
        val controller = mediaController ?: return
        val clamped = positionMs.coerceIn(0L, _playerState.value.durationMs.coerceAtLeast(1L))
        controller.seekTo(clamped)
        _playerState.value = _playerState.value.copy(currentPositionMs = clamped)
        persistCurrentPlaybackPosition()
    }

    fun toggleShuffle() {
        val controller = mediaController ?: return
        val nextShuffle = !controller.shuffleModeEnabled
        controller.shuffleModeEnabled = nextShuffle
        _playerState.value = _playerState.value.copy(shuffleEnabled = nextShuffle)
        viewModelScope.launch {
            prefsRepo.setShuffleAndRepeat(nextShuffle, controller.repeatMode)
        }
    }

    fun cycleRepeatMode() {
        val controller = mediaController ?: return
        val nextRepeat = when (controller.repeatMode) {
            Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
            Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
            else -> Player.REPEAT_MODE_OFF
        }
        controller.repeatMode = nextRepeat
        _playerState.value = _playerState.value.copy(repeatMode = nextRepeat)
        viewModelScope.launch {
            prefsRepo.setShuffleAndRepeat(controller.shuffleModeEnabled, nextRepeat)
        }
    }

    // Queue Management
    fun playNextInQueue(song: Song) {
        val controller = mediaController ?: return
        val currentQueue = _playerState.value.queue.toMutableList()
        if (currentQueue.isEmpty()) {
            playSongList(listOf(song), 0)
            return
        }
        val insertIndex = (controller.currentMediaItemIndex + 1).coerceAtMost(currentQueue.size)
        currentQueue.add(insertIndex, song)
        controller.addMediaItem(insertIndex, song.toMediaItem())
        _playerState.value = _playerState.value.copy(queue = currentQueue)
    }

    fun addToQueueEnd(song: Song) {
        val controller = mediaController ?: return
        val currentQueue = _playerState.value.queue.toMutableList()
        if (currentQueue.isEmpty()) {
            playSongList(listOf(song), 0)
            return
        }
        currentQueue.add(song)
        controller.addMediaItem(song.toMediaItem())
        _playerState.value = _playerState.value.copy(queue = currentQueue)
    }

    fun removeFromQueue(index: Int) {
        val controller = mediaController ?: return
        val currentQueue = _playerState.value.queue.toMutableList()
        if (index !in currentQueue.indices) return
        currentQueue.removeAt(index)
        controller.removeMediaItem(index)
        _playerState.value = _playerState.value.copy(
            queue = currentQueue,
            currentQueueIndex = controller.currentMediaItemIndex
        )
    }

    fun moveQueueItem(fromIndex: Int, toIndex: Int) {
        val controller = mediaController ?: return
        val currentQueue = _playerState.value.queue.toMutableList()
        if (fromIndex !in currentQueue.indices || toIndex !in currentQueue.indices) return
        val item = currentQueue.removeAt(fromIndex)
        currentQueue.add(toIndex, item)
        controller.moveMediaItem(fromIndex, toIndex)
        _playerState.value = _playerState.value.copy(
            queue = currentQueue,
            currentQueueIndex = controller.currentMediaItemIndex
        )
    }

    fun jumpToQueueIndex(index: Int) {
        val controller = mediaController ?: return
        if (index in _playerState.value.queue.indices) {
            controller.seekTo(index, 0L)
            controller.play()
        }
    }

    // Favorites & Playlists
    fun toggleFavorite(songId: Long) {
        viewModelScope.launch {
            repository.toggleFavorite(songId)
        }
    }

    fun createPlaylist(name: String) {
        if (name.isBlank()) return
        viewModelScope.launch {
            repository.createPlaylist(name)
        }
    }

    fun deletePlaylist(playlistId: Long) {
        viewModelScope.launch {
            repository.deletePlaylist(playlistId)
        }
    }

    fun addSongToPlaylist(playlistId: Long, songId: Long) {
        viewModelScope.launch {
            repository.addSongToPlaylist(playlistId, songId)
        }
    }

    fun removeSongFromPlaylist(playlistId: Long, songId: Long) {
        viewModelScope.launch {
            repository.removeSongFromPlaylist(playlistId, songId)
        }
    }

    // Playback Speed, Audio Balance, Volume & Gapless
    fun setPlaybackSpeed(speed: Float, pitch: Float = _playerState.value.playbackPitch) {
        val clampedSpeed = speed.coerceIn(0.25f, 3.0f)
        val clampedPitch = pitch.coerceIn(0.5f, 2.0f)
        mediaController?.playbackParameters = PlaybackParameters(clampedSpeed, clampedPitch)
        _playerState.value = _playerState.value.copy(
            playbackSpeed = clampedSpeed,
            playbackPitch = clampedPitch
        )
        viewModelScope.launch {
            prefsRepo.setPlaybackSpeedAndPitch(clampedSpeed, clampedPitch)
        }
    }

    fun setAudioBalanceAndVolume(balance: Float, volume: Float) {
        val clampedBalance = balance.coerceIn(-1.0f, 1.0f)
        val clampedVolume = volume.coerceIn(0.0f, 1.0f)
        app.balanceProcessor.setBalanceAndGain(clampedBalance, clampedVolume)
        _playerState.value = _playerState.value.copy(
            audioBalance = clampedBalance,
            masterVolume = clampedVolume
        )
        viewModelScope.launch {
            prefsRepo.setAudioBalanceAndVolume(clampedBalance, clampedVolume)
        }
    }

    fun setGaplessPlayback(enabled: Boolean) {
        _playerState.value = _playerState.value.copy(gaplessPlayback = enabled)
        viewModelScope.launch {
            prefsRepo.setGaplessPlayback(enabled)
        }
    }

    // Equalizer, Bass Boost & Virtualizer
    fun setEqualizerEnabled(enabled: Boolean) {
        audioEffectsController.setEnabled(enabled)
        persistEqualizerState()
    }

    fun selectEqualizerPreset(presetIndex: Int) {
        audioEffectsController.selectPreset(presetIndex)
        persistEqualizerState()
    }

    fun setEqualizerBandLevel(bandIndex: Short, levelMb: Short) {
        audioEffectsController.setBandLevel(bandIndex, levelMb)
        persistEqualizerState()
    }

    fun setBassBoost(strength: Int) {
        audioEffectsController.setBassBoost(strength)
        persistEqualizerState()
    }

    fun setVirtualizer(strength: Int) {
        audioEffectsController.setVirtualizer(strength)
        persistEqualizerState()
    }

    private fun persistEqualizerState() {
        val eq = equalizerState.value
        viewModelScope.launch {
            prefsRepo.saveEqualizerState(
                enabled = eq.isEnabled,
                presetIndex = eq.selectedPresetIndex,
                bandLevels = eq.bands.map { it.currentLevelMb },
                bassBoost = eq.bassBoostStrength,
                virtualizer = eq.virtualizerStrength
            )
        }
    }

    // Custom / Edited Synchronized LRC Lyrics
    fun saveCustomLyricsForCurrentSong(rawLrcText: String) {
        val song = _playerState.value.currentSong ?: return
        viewModelScope.launch {
            repository.saveCustomLrcLyrics(song.id, rawLrcText)
            val updated = repository.getLyricsForSong(song)
            _playerState.value = _playerState.value.copy(lyrics = updated)
        }
    }

    // Sleep Timer
    fun startSleepTimer(minutes: Int) {
        sleepTimerJob?.cancel()
        if (minutes <= 0) {
            _playerState.value = _playerState.value.copy(sleepTimerRemainingSec = 0L)
            return
        }
        val totalSeconds = minutes * 60L
        _playerState.value = _playerState.value.copy(sleepTimerRemainingSec = totalSeconds)
        sleepTimerJob = viewModelScope.launch {
            var remaining = totalSeconds
            while (remaining > 0 && isActive) {
                delay(1000L)
                remaining--
                _playerState.value = _playerState.value.copy(sleepTimerRemainingSec = remaining)
            }
            if (remaining <= 0L) {
                mediaController?.pause()
                _playerState.value = _playerState.value.copy(sleepTimerRemainingSec = 0L)
            }
        }
    }

    // Theme & Accent Customization
    fun setThemeMode(mode: ThemeMode) {
        viewModelScope.launch {
            prefsRepo.setThemeMode(mode)
        }
    }

    fun setAccentPreset(preset: AccentPreset) {
        viewModelScope.launch {
            prefsRepo.setAccentPreset(preset)
        }
    }

    private fun sortSongs(songs: List<Song>, option: SortOption): List<Song> {
        return when (option) {
            SortOption.TITLE_ASC -> songs.sortedBy { it.title.lowercase() }
            SortOption.TITLE_DESC -> songs.sortedByDescending { it.title.lowercase() }
            SortOption.DURATION_DESC -> songs.sortedByDescending { it.duration }
            SortOption.DURATION_ASC -> songs.sortedBy { it.duration }
            SortOption.DATE_MODIFIED_DESC -> songs.sortedByDescending { it.dateModifiedSec }
            SortOption.RECENTLY_ADDED -> songs.sortedByDescending { it.dateAddedSec }
        }
    }

    private fun Song.toMediaItem(): MediaItem {
        val metadata = MediaMetadata.Builder()
            .setTitle(title)
            .setArtist(artist)
            .setAlbumTitle(album)
            .setArtworkUri(albumArtUri)
            .build()

        return MediaItem.Builder()
            .setMediaId(id.toString())
            .setUri(uri)
            .setMediaMetadata(metadata)
            .build()
    }

    override fun onCleared() {
        persistCurrentPlaybackPosition()
        controllerFuture?.let { MediaController.releaseFuture(it) }
        audioEffectsController.release()
        super.onCleared()
    }
}
