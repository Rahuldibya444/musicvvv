package com.rahul.music.data.model

import android.net.Uri

enum class SortOption(val displayName: String) {
    TITLE_ASC("Name (A–Z)"),
    TITLE_DESC("Name (Z–A)"),
    DURATION_DESC("Duration (Longest)"),
    DURATION_ASC("Duration (Shortest)"),
    DATE_MODIFIED_DESC("Date (Newest)"),
    RECENTLY_ADDED("Recently Added")
}

enum class LibraryTab(val title: String) {
    SONGS("Songs"),
    ALBUMS("Albums"),
    ARTISTS("Artists"),
    FOLDERS("Folders"),
    GENRES("Genres"),
    PLAYLISTS("Playlists")
}

enum class ThemeMode(val label: String) {
    AMOLED_BLACK("AMOLED Pitch Black"),
    DARK_CARBON("Dark Carbon"),
    LIGHT("Clean Light"),
    SYSTEM("Follow System")
}

enum class AccentPreset(val label: String, val hexColor: Long) {
    CRIMSON_RED("Rahul Crimson", 0xFFFF1744),
    SCARLET_PULSE("Scarlet Pulse", 0xFFFF3D00),
    RUBY_NEON("Ruby Neon", 0xFFF50057),
    ELECTRIC_CORAL("Electric Coral", 0xFFFF5252),
    PLATINUM_WHITE("Pure Monochrome", 0xFFFFFFFF)
}

data class Song(
    val id: Long,
    val title: String,
    val artist: String,
    val artistId: Long,
    val album: String,
    val albumId: Long,
    val duration: Long,
    val uri: Uri,
    val albumArtUri: Uri?,
    val path: String,
    val folderName: String,
    val folderPath: String,
    val genre: String,
    val mimeType: String,
    val sizeBytes: Long,
    val bitrateKbps: Int,
    val sampleRateHz: Int,
    val dateAddedSec: Long,
    val dateModifiedSec: Long,
    val trackNumber: Int
) {
    val formatBadge: String
        get() {
            val ext = path.substringAfterLast('.', "").uppercase()
            return if (ext.isNotBlank()) ext else mimeType.substringAfterLast('/').uppercase()
        }
}

data class Album(
    val id: Long,
    val name: String,
    val artist: String,
    val albumArtUri: Uri?,
    val songCount: Int,
    val year: Int,
    val songs: List<Song>
)

data class Artist(
    val id: Long,
    val name: String,
    val songCount: Int,
    val albumCount: Int,
    val artworkUri: Uri?,
    val songs: List<Song>
)

data class MusicFolder(
    val path: String,
    val name: String,
    val songCount: Int,
    val isSafTree: Boolean = false,
    val songs: List<Song>
)

data class GenreGroup(
    val name: String,
    val songCount: Int,
    val songs: List<Song>
)

data class LyricLine(
    val timestampMs: Long,
    val text: String
)

data class EqualizerBandState(
    val index: Short,
    val centerFreqHz: Int,
    val minLevelMb: Short,
    val maxLevelMb: Short,
    val currentLevelMb: Short
)
