package com.rahul.music

import android.app.Application
import androidx.annotation.OptIn
import androidx.media3.common.util.UnstableApi
import com.rahul.music.data.local.RahulMusicDatabase
import com.rahul.music.data.preferences.UserPreferencesRepository
import com.rahul.music.data.repository.MusicRepository
import com.rahul.music.data.scanner.MediaStoreScanner
import com.rahul.music.player.AudioBalanceProcessor
import com.rahul.music.player.AudioEffectsController
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

@OptIn(UnstableApi::class)
class RahulMusicApp : Application() {

    private val appScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    lateinit var database: RahulMusicDatabase
        private set
    lateinit var preferencesRepository: UserPreferencesRepository
        private set
    lateinit var musicRepository: MusicRepository
        private set
    lateinit var audioEffectsController: AudioEffectsController
        private set

    val balanceProcessor = AudioBalanceProcessor()

    override fun onCreate() {
        super.onCreate()
        database = RahulMusicDatabase.getInstance(this)
        preferencesRepository = UserPreferencesRepository(this)
        val scanner = MediaStoreScanner(this)
        musicRepository = MusicRepository(database.musicDao(), scanner)
        audioEffectsController = AudioEffectsController()

        // Apply persisted stereo balance & master volume on startup
        appScope.launch {
            val prefs = preferencesRepository.settingsFlow.first()
            balanceProcessor.setBalanceAndGain(prefs.audioBalance, prefs.masterVolume)
        }
    }

    fun onPlayerAudioSessionReady(audioSessionId: Int) {
        appScope.launch {
            val prefs = preferencesRepository.settingsFlow.first()
            audioEffectsController.bindToAudioSession(
                audioSessionId = audioSessionId,
                enabled = prefs.equalizerEnabled,
                presetIndex = prefs.equalizerPresetIndex,
                savedBandLevelsCsv = prefs.equalizerBandLevelsCsv,
                bassStrength = prefs.bassBoostStrength,
                virtualizerStrength = prefs.virtualizerStrength
            )
        }
    }
}
