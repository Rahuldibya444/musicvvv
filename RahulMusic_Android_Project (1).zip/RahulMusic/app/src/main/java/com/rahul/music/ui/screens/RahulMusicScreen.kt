package com.rahul.music.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.Sort
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Album
import androidx.compose.material.icons.rounded.Clear
import androidx.compose.material.icons.rounded.CreateNewFolder
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Equalizer
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.rahul.music.data.model.LibraryTab
import com.rahul.music.data.model.Song
import com.rahul.music.data.model.SortOption
import com.rahul.music.ui.components.AlbumArtworkImage
import com.rahul.music.ui.components.AudioFormatBadge
import com.rahul.music.ui.viewmodel.PlayerUiState
import com.rahul.music.ui.viewmodel.RahulViewModel
import com.rahul.music.utils.FormatUtils

private data class DrillDownGroup(
    val title: String,
    val subtitle: String,
    val songs: List<Song>,
    val playlistId: Long? = null
)

@Composable
fun RahulMusicScreen(
    viewModel: RahulViewModel,
    hasStoragePermission: Boolean,
    onRequestPermission: () -> Unit,
    onLaunchSafPicker: () -> Unit
) {
    val libraryState by viewModel.libraryState.collectAsState()
    val playerState by viewModel.playerState.collectAsState()
    val eqState by viewModel.equalizerState.collectAsState()
    val settings by viewModel.settingsState.collectAsState()

    var isFullScreenPlayerOpen by remember { mutableStateOf(false) }
    var activeDrillDown by remember { mutableStateOf<DrillDownGroup?>(null) }
    var showSortMenu by remember { mutableStateOf(false) }
    var showEqualizerSheet by remember { mutableStateOf(false) }
    var showSpeedBalanceSheet by remember { mutableStateOf(false) }
    var showQueueSheet by remember { mutableStateOf(false) }
    var showSleepTimerDialog by remember { mutableStateOf(false) }
    var showThemeDialog by remember { mutableStateOf(false) }
    var showLyricsEditorDialog by remember { mutableStateOf(false) }
    var songForPlaylistDialog by remember { mutableStateOf<Song?>(null) }

    BackHandler(enabled = isFullScreenPlayerOpen || activeDrillDown != null) {
        if (isFullScreenPlayerOpen) {
            isFullScreenPlayerOpen = false
        } else {
            activeDrillDown = null
        }
    }

    val primary = MaterialTheme.colorScheme.primary

    Box(modifier = Modifier.fillMaxSize()) {
        Scaffold(
            topBar = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(MaterialTheme.colorScheme.background)
                        .statusBarsPadding()
                        .padding(horizontal = 16.dp, vertical = 10.dp)
                ) {
                    // Brand Bar
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(primary.copy(alpha = 0.18f))
                                    .border(1.5.dp, primary, CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "R",
                                    style = MaterialTheme.typography.titleLarge,
                                    color = primary,
                                    fontWeight = FontWeight.ExtraBold
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "Rahul Music",
                                    style = MaterialTheme.typography.headlineMedium
                                )
                                Text(
                                    text = "${libraryState.allSongs.size} Offline Tracks",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(onClick = onLaunchSafPicker) {
                                Icon(
                                    imageVector = Icons.Rounded.CreateNewFolder,
                                    contentDescription = "Add SD / SAF Music Folder"
                                )
                            }
                            IconButton(onClick = { showEqualizerSheet = true }) {
                                Icon(
                                    imageVector = Icons.Rounded.Equalizer,
                                    contentDescription = "Equalizer",
                                    tint = if (eqState.isEnabled) primary else MaterialTheme.colorScheme.onSurface
                                )
                            }
                            IconButton(onClick = { showThemeDialog = true }) {
                                Icon(
                                    imageVector = Icons.Rounded.Palette,
                                    contentDescription = "Theme & Accent Colors"
                                )
                            }
                            IconButton(onClick = { viewModel.scanMediaLibrary() }) {
                                Icon(
                                    imageVector = Icons.Rounded.Refresh,
                                    contentDescription = "Rescan Local Storage"
                                )
                            }
                            Box {
                                IconButton(onClick = { showSortMenu = true }) {
                                    Icon(
                                        imageVector = Icons.AutoMirrored.Rounded.Sort,
                                        contentDescription = "Sort Songs"
                                    )
                                }
                                DropdownMenu(
                                    expanded = showSortMenu,
                                    onDismissRequest = { showSortMenu = false }
                                ) {
                                    SortOption.entries.forEach { option ->
                                        DropdownMenuItem(
                                            text = {
                                                Text(
                                                    text = option.displayName,
                                                    color = if (libraryState.sortOption == option) primary
                                                    else MaterialTheme.colorScheme.onSurface,
                                                    fontWeight = if (libraryState.sortOption == option) FontWeight.Bold
                                                    else FontWeight.Normal
                                                )
                                            },
                                            onClick = {
                                                viewModel.setSortOption(option)
                                                showSortMenu = false
                                            }
                                        )
                                    }
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Instant Search Bar
                    OutlinedTextField(
                        value = libraryState.searchQuery,
                        onValueChange = viewModel::setSearchQuery,
                        placeholder = { Text("Search songs, artists, albums, folders, genres...") },
                        leadingIcon = {
                            Icon(Icons.Rounded.Search, contentDescription = null, tint = primary)
                        },
                        trailingIcon = {
                            if (libraryState.searchQuery.isNotEmpty()) {
                                IconButton(onClick = { viewModel.setSearchQuery("") }) {
                                    Icon(Icons.Rounded.Clear, contentDescription = "Clear Search")
                                }
                            }
                        },
                        singleLine = true,
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Category Navigation Tabs
                    ScrollableTabRow(
                        selectedTabIndex = libraryState.selectedTab.ordinal,
                        edgePadding = 0.dp,
                        containerColor = MaterialTheme.colorScheme.background,
                        contentColor = primary,
                        divider = {}
                    ) {
                        LibraryTab.entries.forEach { tab ->
                            val selected = libraryState.selectedTab == tab
                            Tab(
                                selected = selected,
                                onClick = {
                                    activeDrillDown = null
                                    viewModel.selectTab(tab)
                                },
                                text = {
                                    Text(
                                        text = tab.title,
                                        fontWeight = if (selected) FontWeight.ExtraBold else FontWeight.Medium,
                                        color = if (selected) primary else MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            )
                        }
                    }
                }
            },
            bottomBar = {
                AnimatedVisibility(visible = playerState.currentSong != null) {
                    MiniPlayerBar(
                        playerState = playerState,
                        onOpenFullScreen = { isFullScreenPlayerOpen = true },
                        onPlayPause = viewModel::togglePlayPause,
                        onNext = viewModel::skipToNext
                    )
                }
            }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                if (!hasStoragePermission) {
                    PermissionPromptState(
                        onGrantPermission = onRequestPermission,
                        onOpenSafFolder = onLaunchSafPicker
                    )
                } else if (libraryState.isScanning && libraryState.allSongs.isEmpty()) {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            CircularProgressIndicator(color = primary)
                            Spacer(modifier = Modifier.height(12.dp))
                            Text("Scanning local storage & SD card audio files...")
                        }
                    }
                } else if (activeDrillDown != null) {
                    val group = activeDrillDown!!
                    DrillDownSongListScreen(
                        group = group,
                        currentSongId = playerState.currentSong?.id,
                        favoriteIds = libraryState.favoriteIds,
                        onBack = { activeDrillDown = null },
                        onPlaySongAt = { idx -> viewModel.playSongList(group.songs, idx) },
                        onToggleFavorite = viewModel::toggleFavorite,
                        onPlayNext = viewModel::playNextInQueue,
                        onAddToQueue = viewModel::addToQueueEnd,
                        onAddToPlaylist = { songForPlaylistDialog = it },
                        onRemoveFromPlaylist = group.playlistId?.let { plId ->
                            { songId -> viewModel.removeSongFromPlaylist(plId, songId) }
                        }
                    )
                } else {
                    when (libraryState.selectedTab) {
                        LibraryTab.SONGS -> {
                            SongsTabContent(
                                songs = libraryState.filteredSongs,
                                favoriteSongs = libraryState.favoriteSongs,
                                recentSongs = libraryState.recentlyPlayedSongs,
                                currentSongId = playerState.currentSong?.id,
                                favoriteIds = libraryState.favoriteIds,
                                onOpenFavorites = {
                                    activeDrillDown = DrillDownGroup(
                                        title = "Favorite Tracks",
                                        subtitle = "${libraryState.favoriteSongs.size} songs",
                                        songs = libraryState.favoriteSongs
                                    )
                                },
                                onOpenRecentlyPlayed = {
                                    activeDrillDown = DrillDownGroup(
                                        title = "Recently Played",
                                        subtitle = "${libraryState.recentlyPlayedSongs.size} songs",
                                        songs = libraryState.recentlyPlayedSongs
                                    )
                                },
                                onPlaySongAt = { idx -> viewModel.playSongList(libraryState.filteredSongs, idx) },
                                onToggleFavorite = viewModel::toggleFavorite,
                                onPlayNext = viewModel::playNextInQueue,
                                onAddToQueue = viewModel::addToQueueEnd,
                                onAddToPlaylist = { songForPlaylistDialog = it },
                                onRescan = viewModel::scanMediaLibrary,
                                onOpenSaf = onLaunchSafPicker
                            )
                        }

                        LibraryTab.ALBUMS -> {
                            LazyVerticalGrid(
                                columns = GridCells.Adaptive(minSize = 155.dp),
                                contentPadding = PaddingValues(16.dp),
                                horizontalArrangement = Arrangement.spacedBy(12.dp),
                                verticalArrangement = Arrangement.spacedBy(12.dp),
                                modifier = Modifier.fillMaxSize()
                            ) {
                                items(libraryState.albums, key = { it.id }) { album ->
                                    Column(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(16.dp))
                                            .background(MaterialTheme.colorScheme.surface)
                                            .border(0.8.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(16.dp))
                                            .clickable {
                                                activeDrillDown = DrillDownGroup(
                                                    title = album.name,
                                                    subtitle = "${album.artist} • ${album.songCount} songs",
                                                    songs = album.songs
                                                )
                                            }
                                            .padding(10.dp)
                                    ) {
                                        AlbumArtworkImage(
                                            artworkUri = album.albumArtUri,
                                            contentDescription = album.name,
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .height(135.dp)
                                        )
                                        Spacer(modifier = Modifier.height(8.dp))
                                        Text(
                                            text = album.name,
                                            style = MaterialTheme.typography.titleMedium,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        Text(
                                            text = "${album.artist} • ${album.songCount} tracks",
                                            style = MaterialTheme.typography.bodyMedium,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                }
                            }
                        }

                        LibraryTab.ARTISTS -> {
                            LazyColumn(
                                contentPadding = PaddingValues(16.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp),
                                modifier = Modifier.fillMaxSize()
                            ) {
                                itemsIndexed(libraryState.artists) { _, artist ->
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(14.dp))
                                            .background(MaterialTheme.colorScheme.surface)
                                            .border(0.8.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(14.dp))
                                            .clickable {
                                                activeDrillDown = DrillDownGroup(
                                                    title = artist.name,
                                                    subtitle = "${artist.albumCount} albums • ${artist.songCount} songs",
                                                    songs = artist.songs
                                                )
                                            }
                                            .padding(12.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(
                                            imageVector = Icons.Rounded.Person,
                                            contentDescription = null,
                                            tint = primary,
                                            modifier = Modifier.size(36.dp)
                                        )
                                        Spacer(modifier = Modifier.width(12.dp))
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(artist.name, style = MaterialTheme.typography.titleMedium)
                                            Text(
                                                "${artist.albumCount} albums • ${artist.songCount} songs",
                                                style = MaterialTheme.typography.bodyMedium,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        LibraryTab.FOLDERS -> {
                            LazyColumn(
                                contentPadding = PaddingValues(16.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp),
                                modifier = Modifier.fillMaxSize()
                            ) {
                                item {
                                    OutlinedButton(
                                        onClick = onLaunchSafPicker,
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Icon(Icons.Rounded.CreateNewFolder, contentDescription = null)
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text("Mount Additional SD Card / Storage Folder (SAF)")
                                    }
                                    Spacer(modifier = Modifier.height(6.dp))
                                }
                                itemsIndexed(libraryState.folders) { _, folder ->
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(14.dp))
                                            .background(MaterialTheme.colorScheme.surface)
                                            .border(0.8.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(14.dp))
                                            .clickable {
                                                activeDrillDown = DrillDownGroup(
                                                    title = folder.name,
                                                    subtitle = "${folder.path} • ${folder.songCount} songs",
                                                    songs = folder.songs
                                                )
                                            }
                                            .padding(12.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(
                                            imageVector = Icons.Rounded.Folder,
                                            contentDescription = null,
                                            tint = primary,
                                            modifier = Modifier.size(34.dp)
                                        )
                                        Spacer(modifier = Modifier.width(12.dp))
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(folder.name, style = MaterialTheme.typography.titleMedium)
                                            Text(
                                                text = "${folder.songCount} tracks • ${folder.path}",
                                                style = MaterialTheme.typography.bodyMedium,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        LibraryTab.GENRES -> {
                            LazyColumn(
                                contentPadding = PaddingValues(16.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp),
                                modifier = Modifier.fillMaxSize()
                            ) {
                                itemsIndexed(libraryState.genres) { _, genre ->
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(14.dp))
                                            .background(MaterialTheme.colorScheme.surface)
                                            .border(0.8.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(14.dp))
                                            .clickable {
                                                activeDrillDown = DrillDownGroup(
                                                    title = genre.name,
                                                    subtitle = "${genre.songCount} songs",
                                                    songs = genre.songs
                                                )
                                            }
                                            .padding(14.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(Icons.Rounded.Album, contentDescription = null, tint = primary)
                                            Spacer(modifier = Modifier.width(12.dp))
                                            Text(genre.name, style = MaterialTheme.typography.titleMedium)
                                        }
                                        Text(
                                            "${genre.songCount} tracks",
                                            style = MaterialTheme.typography.bodyMedium,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                            }
                        }

                        LibraryTab.PLAYLISTS -> {
                            var newPlaylistInput by remember { mutableStateOf("") }
                            LazyColumn(
                                contentPadding = PaddingValues(16.dp),
                                verticalArrangement = Arrangement.spacedBy(10.dp),
                                modifier = Modifier.fillMaxSize()
                            ) {
                                item {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        OutlinedTextField(
                                            value = newPlaylistInput,
                                            onValueChange = { newPlaylistInput = it },
                                            placeholder = { Text("Create custom playlist...") },
                                            singleLine = true,
                                            modifier = Modifier.weight(1f)
                                        )
                                        Button(
                                            onClick = {
                                                if (newPlaylistInput.isNotBlank()) {
                                                    viewModel.createPlaylist(newPlaylistInput)
                                                    newPlaylistInput = ""
                                                }
                                            }
                                        ) {
                                            Icon(Icons.Rounded.Add, contentDescription = null)
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("Create")
                                        }
                                    }
                                }

                                itemsIndexed(libraryState.playlists) { _, pl ->
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(14.dp))
                                            .background(MaterialTheme.colorScheme.surface)
                                            .border(0.8.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(14.dp))
                                            .clickable {
                                                activeDrillDown = DrillDownGroup(
                                                    title = pl.name,
                                                    subtitle = "${pl.songs.size} tracks",
                                                    songs = pl.songs,
                                                    playlistId = pl.id
                                                )
                                            }
                                            .padding(14.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(pl.name, style = MaterialTheme.typography.titleMedium)
                                            Text(
                                                "${pl.songs.size} songs",
                                                style = MaterialTheme.typography.bodyMedium,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                        IconButton(onClick = { viewModel.deletePlaylist(pl.id) }) {
                                            Icon(Icons.Rounded.DeleteOutline, contentDescription = "Delete Playlist")
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Full-Screen Player Overlay
        AnimatedVisibility(
            visible = isFullScreenPlayerOpen && playerState.currentSong != null,
            enter = slideInVertically(initialOffsetY = { it }),
            exit = slideOutVertically(targetOffsetY = { it })
        ) {
            NowPlayingScreen(
                playerState = playerState,
                isFavorite = playerState.currentSong?.id in libraryState.favoriteIds,
                onCollapse = { isFullScreenPlayerOpen = false },
                onPlayPause = viewModel::togglePlayPause,
                onNext = viewModel::skipToNext,
                onPrevious = viewModel::skipToPrevious,
                onSeek = viewModel::seekToPosition,
                onToggleShuffle = viewModel::toggleShuffle,
                onCycleRepeat = viewModel::cycleRepeatMode,
                onToggleFavorite = viewModel::toggleFavorite,
                onOpenQueue = { showQueueSheet = true },
                onOpenEqualizer = { showEqualizerSheet = true },
                onOpenSpeedAndBalance = { showSpeedBalanceSheet = true },
                onOpenSleepTimer = { showSleepTimerDialog = true },
                onOpenAddToPlaylist = { songForPlaylistDialog = it },
                onOpenLyricsEditor = { showLyricsEditorDialog = true }
            )
        }
    }

    // Bottom Sheets & Dialogs
    if (showEqualizerSheet) {
        EqualizerBottomSheet(
            eqState = eqState,
            onDismiss = { showEqualizerSheet = false },
            onToggleEnabled = viewModel::setEqualizerEnabled,
            onSelectPreset = viewModel::selectEqualizerPreset,
            onBandLevelChanged = viewModel::setEqualizerBandLevel,
            onBassBoostChanged = viewModel::setBassBoost,
            onVirtualizerChanged = viewModel::setVirtualizer
        )
    }

    if (showSpeedBalanceSheet) {
        SpeedAndBalanceBottomSheet(
            playerState = playerState,
            onDismiss = { showSpeedBalanceSheet = false },
            onSpeedChanged = { viewModel.setPlaybackSpeed(it) },
            onBalanceAndVolumeChanged = viewModel::setAudioBalanceAndVolume,
            onGaplessChanged = viewModel::setGaplessPlayback
        )
    }

    if (showQueueSheet) {
        QueueBottomSheet(
            playerState = playerState,
            onDismiss = { showQueueSheet = false },
            onJumpToIndex = viewModel::jumpToQueueIndex,
            onMoveItem = viewModel::moveQueueItem,
            onRemoveItem = viewModel::removeFromQueue
        )
    }

    if (showSleepTimerDialog) {
        SleepTimerDialog(
            remainingSec = playerState.sleepTimerRemainingSec,
            onDismiss = { showSleepTimerDialog = false },
            onSetMinutes = viewModel::startSleepTimer
        )
    }

    if (showThemeDialog) {
        ThemeCustomizationDialog(
            settings = settings,
            onDismiss = { showThemeDialog = false },
            onSelectTheme = viewModel::setThemeMode,
            onSelectAccent = viewModel::setAccentPreset
        )
    }

    songForPlaylistDialog?.let { targetSong ->
        AddToPlaylistDialog(
            song = targetSong,
            playlists = libraryState.playlists,
            onDismiss = { songForPlaylistDialog = null },
            onCreateNewPlaylist = viewModel::createPlaylist,
            onAddSongToPlaylist = viewModel::addSongToPlaylist
        )
    }

    if (showLyricsEditorDialog && playerState.currentSong != null) {
        val currentRaw = playerState.lyrics.joinToString("
") { line ->
            val min = (line.timestampMs / 60000).toString().padStart(2, '0')
            val sec = ((line.timestampMs % 60000) / 1000).toString().padStart(2, '0')
            "[$min:$sec.00] ${line.text}"
        }
        LyricsEditorDialog(
            songTitle = playerState.currentSong!!.title,
            initialLrc = currentRaw,
            onDismiss = { showLyricsEditorDialog = false },
            onSaveLrc = viewModel::saveCustomLyricsForCurrentSong
        )
    }
}

@Composable
private fun SongsTabContent(
    songs: List<Song>,
    favoriteSongs: List<Song>,
    recentSongs: List<Song>,
    currentSongId: Long?,
    favoriteIds: Set<Long>,
    onOpenFavorites: () -> Unit,
    onOpenRecentlyPlayed: () -> Unit,
    onPlaySongAt: (Int) -> Unit,
    onToggleFavorite: (Long) -> Unit,
    onPlayNext: (Song) -> Unit,
    onAddToQueue: (Song) -> Unit,
    onAddToPlaylist: (Song) -> Unit,
    onRescan: () -> Unit,
    onOpenSaf: () -> Unit
) {
    val primary = MaterialTheme.colorScheme.primary
    if (songs.isEmpty()) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = "No Offline Audio Files Found",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Add MP3, FLAC, WAV, AAC, M4A, OGG, OPUS, WMA, or AIFF files to your device or select a folder via Storage Access Framework.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(16.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Button(onClick = onRescan) {
                        Text("Rescan Storage")
                    }
                    OutlinedButton(onClick = onOpenSaf) {
                        Text("Select Folder (SAF)")
                    }
                }
            }
        }
        return
    }

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        item {
            // Quick Access Cards: Favorites & Recently Played
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(16.dp))
                        .background(MaterialTheme.colorScheme.surface)
                        .border(0.8.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(16.dp))
                        .clickable(onClick = onOpenFavorites)
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Rounded.Favorite, contentDescription = null, tint = primary)
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text("Favorites", style = MaterialTheme.typography.titleMedium)
                        Text(
                            "${favoriteSongs.size} tracks",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Row(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(16.dp))
                        .background(MaterialTheme.colorScheme.surface)
                        .border(0.8.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(16.dp))
                        .clickable(onClick = onOpenRecentlyPlayed)
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Rounded.History, contentDescription = null, tint = primary)
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text("Recent", style = MaterialTheme.typography.titleMedium)
                        Text(
                            "${recentSongs.size} tracks",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
            Spacer(modifier = Modifier.height(8.dp))
        }

        itemsIndexed(songs, key = { _, s -> s.id }) { index, song ->
            SongRowItem(
                song = song,
                isPlaying = song.id == currentSongId,
                isFavorite = song.id in favoriteIds,
                onClick = { onPlaySongAt(index) },
                onToggleFavorite = { onToggleFavorite(song.id) },
                onPlayNext = { onPlayNext(song) },
                onAddToQueue = { onAddToQueue(song) },
                onAddToPlaylist = { onAddToPlaylist(song) }
            )
        }
    }
}

@Composable
private fun DrillDownSongListScreen(
    group: DrillDownGroup,
    currentSongId: Long?,
    favoriteIds: Set<Long>,
    onBack: () -> Unit,
    onPlaySongAt: (Int) -> Unit,
    onToggleFavorite: (Long) -> Unit,
    onPlayNext: (Song) -> Unit,
    onAddToQueue: (Song) -> Unit,
    onAddToPlaylist: (Song) -> Unit,
    onRemoveFromPlaylist: ((Long) -> Unit)? = null
) {
    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Back")
                }
                Column {
                    Text(group.title, style = MaterialTheme.typography.titleLarge, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(
                        group.subtitle,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            if (group.songs.isNotEmpty()) {
                Button(onClick = { onPlaySongAt(0) }) {
                    Icon(Icons.Rounded.PlayArrow, contentDescription = null)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Play All")
                }
            }
        }

        LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            itemsIndexed(group.songs, key = { idx, s -> "${s.id}_$idx" }) { index, song ->
                SongRowItem(
                    song = song,
                    isPlaying = song.id == currentSongId,
                    isFavorite = song.id in favoriteIds,
                    onClick = { onPlaySongAt(index) },
                    onToggleFavorite = { onToggleFavorite(song.id) },
                    onPlayNext = { onPlayNext(song) },
                    onAddToQueue = { onAddToQueue(song) },
                    onAddToPlaylist = { onAddToPlaylist(song) },
                    onRemoveFromPlaylist = onRemoveFromPlaylist?.let { remover -> { remover(song.id) } }
                )
            }
        }
    }
}

@Composable
private fun SongRowItem(
    song: Song,
    isPlaying: Boolean,
    isFavorite: Boolean,
    onClick: () -> Unit,
    onToggleFavorite: () -> Unit,
    onPlayNext: () -> Unit,
    onAddToQueue: () -> Unit,
    onAddToPlaylist: () -> Unit,
    onRemoveFromPlaylist: (() -> Unit)? = null
) {
    val primary = MaterialTheme.colorScheme.primary
    var menuExpanded by remember { mutableStateOf(false) }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(
                if (isPlaying) primary.copy(alpha = 0.14f)
                else MaterialTheme.colorScheme.surface
            )
            .border(
                width = 0.8.dp,
                color = if (isPlaying) primary else MaterialTheme.colorScheme.outline,
                shape = RoundedCornerShape(14.dp)
            )
            .clickable(onClick = onClick)
            .padding(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        AlbumArtworkImage(
            artworkUri = song.albumArtUri,
            contentDescription = song.title,
            cornerRadius = 10.dp,
            isPlayingIndicator = isPlaying,
            modifier = Modifier.size(50.dp)
        )
        Spacer(modifier = Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = song.title,
                style = MaterialTheme.typography.titleMedium,
                color = if (isPlaying) primary else MaterialTheme.colorScheme.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = "${song.artist} • ${song.album}",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(modifier = Modifier.height(4.dp))
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                AudioFormatBadge(format = song.formatBadge, bitrateKbps = song.bitrateKbps)
                Text(
                    text = FormatUtils.formatDuration(song.duration),
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        IconButton(onClick = onToggleFavorite) {
            Icon(
                imageVector = if (isFavorite) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder,
                contentDescription = "Favorite",
                tint = if (isFavorite) primary else MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        Box {
            IconButton(onClick = { menuExpanded = true }) {
                Icon(Icons.Rounded.MoreVert, contentDescription = "More Options")
            }
            DropdownMenu(
                expanded = menuExpanded,
                onDismissRequest = { menuExpanded = false }
            ) {
                DropdownMenuItem(
                    text = { Text("Play Next") },
                    onClick = {
                        onPlayNext()
                        menuExpanded = false
                    }
                )
                DropdownMenuItem(
                    text = { Text("Add to Queue") },
                    onClick = {
                        onAddToQueue()
                        menuExpanded = false
                    }
                )
                DropdownMenuItem(
                    text = { Text("Add to Playlist...") },
                    onClick = {
                        onAddToPlaylist()
                        menuExpanded = false
                    }
                )
                if (onRemoveFromPlaylist != null) {
                    DropdownMenuItem(
                        text = { Text("Remove from Playlist") },
                        onClick = {
                            onRemoveFromPlaylist()
                            menuExpanded = false
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun MiniPlayerBar(
    playerState: PlayerUiState,
    onOpenFullScreen: () -> Unit,
    onPlayPause: () -> Unit,
    onNext: () -> Unit
) {
    val song = playerState.currentSong ?: return
    val primary = MaterialTheme.colorScheme.primary
    val progress = if (playerState.durationMs > 0) {
        (playerState.currentPositionMs.toFloat() / playerState.durationMs.toFloat()).coerceIn(0f, 1f)
    } else 0f

    Surface(
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 8.dp,
        modifier = Modifier
            .fillMaxWidth()
            .navigationBarsPadding()
            .padding(horizontal = 12.dp, vertical = 8.dp)
            .clip(RoundedCornerShape(18.dp))
            .border(1.dp, primary.copy(alpha = 0.45f), RoundedCornerShape(18.dp))
            .clickable(onClick = onOpenFullScreen)
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            LinearProgressIndicator(
                progress = { progress },
                color = primary,
                trackColor = MaterialTheme.colorScheme.surfaceVariant,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(3.dp)
            )
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                AlbumArtworkImage(
                    artworkUri = song.albumArtUri,
                    contentDescription = song.title,
                    cornerRadius = 10.dp,
                    isPlayingIndicator = playerState.isPlaying,
                    modifier = Modifier.size(46.dp)
                )
                Spacer(modifier = Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = song.title,
                        style = MaterialTheme.typography.titleMedium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = song.artist,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                IconButton(onClick = onPlayPause) {
                    Icon(
                        imageVector = if (playerState.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                        contentDescription = "Play / Pause",
                        tint = primary,
                        modifier = Modifier.size(30.dp)
                    )
                }
                IconButton(onClick = onNext) {
                    Icon(
                        imageVector = Icons.Rounded.SkipNext,
                        contentDescription = "Next",
                        modifier = Modifier.size(28.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun PermissionPromptState(
    onGrantPermission: () -> Unit,
    onOpenSafFolder: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = "Local Storage Audio Access",
            style = MaterialTheme.typography.headlineMedium
        )
        Spacer(modifier = Modifier.height(10.dp))
        Text(
            text = "Rahul Music operates 100% offline. Grant local audio permission to automatically discover MP3, FLAC, WAV, AAC, M4A, OGG, OPUS, WMA, and AIFF tracks across internal storage and SD cards.",
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(modifier = Modifier.height(20.dp))
        Button(onClick = onGrantPermission, modifier = Modifier.fillMaxWidth()) {
            Text("Grant Audio Storage Permission")
        }
        Spacer(modifier = Modifier.height(10.dp))
        OutlinedButton(onClick = onOpenSafFolder, modifier = Modifier.fillMaxWidth()) {
            Text("Or Select Music Folder Directly (SAF)")
        }
    }
}
