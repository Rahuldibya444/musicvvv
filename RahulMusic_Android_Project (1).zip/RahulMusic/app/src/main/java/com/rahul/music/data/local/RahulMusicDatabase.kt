package com.rahul.music.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        SongEntity::class,
        FavoriteEntity::class,
        RecentHistoryEntity::class,
        PlaylistEntity::class,
        PlaylistSongCrossRef::class,
        SafFolderEntity::class,
        CustomLyricsEntity::class
    ],
    version = 1,
    exportSchema = true
)
abstract class RahulMusicDatabase : RoomDatabase() {
    abstract fun musicDao(): MusicDao

    companion object {
        @Volatile
        private var INSTANCE: RahulMusicDatabase? = null

        fun getInstance(context: Context): RahulMusicDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    RahulMusicDatabase::class.java,
                    "rahul_music.db"
                )
                    .fallbackToDestructiveMigration()
                    .build()
                    .also { INSTANCE = it }
            }
        }
    }
}
