package com.rahul.music.ui.components

import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.SubcomposeAsyncImage

@Composable
fun AlbumArtworkImage(
    artworkUri: Uri?,
    contentDescription: String?,
    modifier: Modifier = Modifier,
    cornerRadius: Dp = 14.dp,
    isPlayingIndicator: Boolean = false
) {
    val shape = RoundedCornerShape(cornerRadius)
    val primary = MaterialTheme.colorScheme.primary

    Box(
        modifier = modifier
            .clip(shape)
            .background(
                Brush.linearGradient(
                    colors = listOf(
                        Color(0xFF1A0910),
                        Color(0xFF0E0E14),
                        Color(0xFF280814)
                    )
                )
            )
            .border(0.8.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.6f), shape),
        contentAlignment = Alignment.Center
    ) {
        if (artworkUri != null) {
            SubcomposeAsyncImage(
                model = artworkUri,
                contentDescription = contentDescription,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize(),
                error = {
                    DefaultVinylPlaceholder(primary = primary, isPlaying = isPlayingIndicator)
                },
                loading = {
                    DefaultVinylPlaceholder(primary = primary, isPlaying = isPlayingIndicator)
                }
            )
        } else {
            DefaultVinylPlaceholder(primary = primary, isPlaying = isPlayingIndicator)
        }
    }
}

@Composable
private fun DefaultVinylPlaceholder(primary: Color, isPlaying: Boolean) {
    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = if (isPlaying) Icons.Rounded.GraphicEq else Icons.Rounded.MusicNote,
            contentDescription = null,
            tint = primary.copy(alpha = 0.85f),
            modifier = Modifier.size(28.dp)
        )
    }
}

@Composable
fun AudioFormatBadge(format: String, bitrateKbps: Int) {
    val primary = MaterialTheme.colorScheme.primary
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(6.dp))
            .background(primary.copy(alpha = 0.14f))
            .border(0.7.dp, primary.copy(alpha = 0.45f), RoundedCornerShape(6.dp))
            .padding(horizontal = 6.dp, vertical = 2.dp)
    ) {
        Text(
            text = if (bitrateKbps > 0) "$format • ${bitrateKbps}k" else format,
            color = primary,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold
        )
    }
}
