package com.rahul.music.data.local

import androidx.room.Embedded
import androidx.room.Entity
import androidx.room.Index
import androidx.room.Junction
import androidx.room.PrimaryKey
import androidx.room.Relation

@Entity(tableName = "cached_songs", indices = [Index("title"), Index("albumId"), Index("artistId")])
data class SongEntity(
    @PrimaryKey val id: Long,
    val title: String,
    val artist: String,
    val artistId: Long,
    val album: String,
    val albumId: Long,
    val duration: Long,
    val uriString: String,
    val albumArtUriString: String?,
    val path: String,
    val folderName: String,
    val folderPath: String,
    val genre: String,
    val mimeType: String,
    val sizeBytes: Long,
    val bitrateKbps: Int,
    val sampleRateHz: Int,
    val dateAddedSec: Long,
    val dateModifiedSec: Long,
    val trackNumber: Int
)

@Entity(tableName = "favorites")
data class FavoriteEntity(
    @PrimaryKey val songId: Long,
    val addedAtMs: Long = System.currentTimeMillis()
)

@Entity(tableName = "recent_history")
data class RecentHistoryEntity(
    @PrimaryKey val songId: Long,
    val playedAtMs: Long = System.currentTimeMillis(),
    val playCount: Int = 1
)

@Entity(tableName = "playlists")
data class PlaylistEntity(
    @PrimaryKey(autoGenerate = true) val playlistId: Long = 0L,
    val name: String,
    val createdAtMs: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "playlist_songs",
    primaryKeys = ["playlistId", "songId"],
    indices = [Index("songId"), Index("playlistId")]
)
data class PlaylistSongCrossRef(
    val playlistId: Long,
    val songId: Long,
    val positionOrder: Int,
    val addedAtMs: Long = System.currentTimeMillis()
)

@Entity(tableName = "saf_folders")
data class SafFolderEntity(
    @PrimaryKey val treeUriString: String,
    val displayName: String,
    val addedAtMs: Long = System.currentTimeMillis()
)

@Entity(tableName = "custom_lyrics")
data class CustomLyricsEntity(
    @PrimaryKey val songId: Long,
    val rawLrcContent: String,
    val updatedAtMs: Long = System.currentTimeMillis()
)

data class PlaylistWithSongIds(
    @Embedded val playlist: PlaylistEntity,
    @Relation(
        parentColumn = "playlistId",
        entityColumn = "playlistId"
    )
    val refs: List<PlaylistSongCrossRef>
)
