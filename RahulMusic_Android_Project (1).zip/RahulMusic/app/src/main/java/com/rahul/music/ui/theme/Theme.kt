package com.rahul.music.ui.theme

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import com.rahul.music.data.model.AccentPreset
import com.rahul.music.data.model.ThemeMode

val PitchBlack = Color(0xFF050507)
val DeepCarbon = Color(0xFF0E0E12)
val ElevatedCarbon = Color(0xFF17171E)
val CardBorderDark = Color(0xFF262632)
val PureWhite = Color(0xFFFFFFFF)
val SoftSilver = Color(0xFFB4B4C2)
val MutedGray = Color(0xFF757586)
val RahulCrimson = Color(0xFFFF1744)

val CleanLightBg = Color(0xFFF8F8FA)
val CleanLightSurface = Color(0xFFFFFFFF)
val CleanLightCard = Color(0xFFF0F0F5)
val InkBlack = Color(0xFF0A0A0E)

val RahulTypography = Typography(
    headlineLarge = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.ExtraBold,
        fontSize = 28.sp,
        letterSpacing = (-0.5).sp
    ),
    headlineMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Bold,
        fontSize = 22.sp,
        letterSpacing = (-0.3).sp
    ),
    titleLarge = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Bold,
        fontSize = 18.sp
    ),
    titleMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.SemiBold,
        fontSize = 15.sp
    ),
    bodyLarge = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Normal,
        fontSize = 15.sp
    ),
    bodyMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Normal,
        fontSize = 13.sp
    ),
    labelMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Medium,
        fontSize = 11.sp,
        letterSpacing = 0.4.sp
    )
)

@Composable
fun RahulMusicTheme(
    themeMode: ThemeMode = ThemeMode.AMOLED_BLACK,
    accentPreset: AccentPreset = AccentPreset.CRIMSON_RED,
    content: @Composable () -> Unit
) {
    val systemDark = isSystemInDarkTheme()
    val useDark = when (themeMode) {
        ThemeMode.AMOLED_BLACK, ThemeMode.DARK_CARBON -> true
        ThemeMode.LIGHT -> false
        ThemeMode.SYSTEM -> systemDark
    }

    val rawAccent = Color(accentPreset.hexColor)
    val primaryColor by animateColorAsState(
        targetValue = if (!useDark && accentPreset == AccentPreset.PLATINUM_WHITE) RahulCrimson else rawAccent,
        animationSpec = tween(350),
        label = "accentColor"
    )

    val bgColor by animateColorAsState(
        targetValue = when {
            !useDark -> CleanLightBg
            themeMode == ThemeMode.DARK_CARBON -> Color(0xFF0D0D11)
            else -> PitchBlack
        },
        animationSpec = tween(350),
        label = "bgColor"
    )

    val surfaceColor by animateColorAsState(
        targetValue = when {
            !useDark -> CleanLightSurface
            themeMode == ThemeMode.DARK_CARBON -> ElevatedCarbon
            else -> DeepCarbon
        },
        animationSpec = tween(350),
        label = "surfaceColor"
    )

    val colorScheme = if (useDark) {
        darkColorScheme(
            primary = primaryColor,
            onPrimary = if (accentPreset == AccentPreset.PLATINUM_WHITE) PitchBlack else PureWhite,
            primaryContainer = primaryColor.copy(alpha = 0.18f),
            onPrimaryContainer = PureWhite,
            secondary = primaryColor,
            onSecondary = PureWhite,
            background = bgColor,
            onBackground = PureWhite,
            surface = surfaceColor,
            onSurface = PureWhite,
            surfaceVariant = ElevatedCarbon,
            onSurfaceVariant = SoftSilver,
            outline = CardBorderDark
        )
    } else {
        lightColorScheme(
            primary = primaryColor,
            onPrimary = PureWhite,
            primaryContainer = primaryColor.copy(alpha = 0.12f),
            onPrimaryContainer = InkBlack,
            secondary = primaryColor,
            onSecondary = PureWhite,
            background = bgColor,
            onBackground = InkBlack,
            surface = surfaceColor,
            onSurface = InkBlack,
            surfaceVariant = CleanLightCard,
            onSurfaceVariant = Color(0xFF4A4A58),
            outline = Color(0xFFDADAE5)
        )
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = RahulTypography,
        content = content
    )
}
