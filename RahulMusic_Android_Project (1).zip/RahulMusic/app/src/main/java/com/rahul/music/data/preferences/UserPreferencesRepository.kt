package com.rahul.music.data.preferences

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.rahul.music.data.model.AccentPreset
import com.rahul.music.data.model.SortOption
import com.rahul.music.data.model.ThemeMode
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "rahul_music_prefs")

data class PersistedSettings(
    val lastPlayedSongId: Long = -1L,
    val lastPlaybackPositionMs: Long = 0L,
    val lastQueueIdsCsv: String = "",
    val shuffleEnabled: Boolean = false,
    val repeatMode: Int = 0, // Player.REPEAT_MODE_OFF = 0, ONE = 1, ALL = 2
    val playbackSpeed: Float = 1.0f,
    val playbackPitch: Float = 1.0f,
    val audioBalance: Float = 0.0f, // -1.0f (Full Left) to +1.0f (Full Right)
    val masterVolume: Float = 1.0f, // 0.0f to 1.0f
    val gaplessPlayback: Boolean = true,
    val equalizerEnabled: Boolean = false,
    val equalizerPresetIndex: Int = 0,
    val equalizerBandLevelsCsv: String = "",
    val bassBoostStrength: Int = 0, // 0..1000
    val virtualizerStrength: Int = 0, // 0..1000
    val sortOption: SortOption = SortOption.TITLE_ASC,
    val themeMode: ThemeMode = ThemeMode.AMOLED_BLACK,
    val accentPreset: AccentPreset = AccentPreset.CRIMSON_RED
)

class UserPreferencesRepository(private val context: Context) {

    private object Keys {
        val LAST_SONG_ID = longPreferencesKey("last_song_id")
        val LAST_POSITION_MS = longPreferencesKey("last_position_ms")
        val LAST_QUEUE_CSV = stringPreferencesKey("last_queue_csv")
        val SHUFFLE = booleanPreferencesKey("shuffle_enabled")
        val REPEAT_MODE = intPreferencesKey("repeat_mode")
        val PLAYBACK_SPEED = floatPreferencesKey("playback_speed")
        val PLAYBACK_PITCH = floatPreferencesKey("playback_pitch")
        val AUDIO_BALANCE = floatPreferencesKey("audio_balance")
        val MASTER_VOLUME = floatPreferencesKey("master_volume")
        val GAPLESS = booleanPreferencesKey("gapless_playback")
        val EQ_ENABLED = booleanPreferencesKey("eq_enabled")
        val EQ_PRESET = intPreferencesKey("eq_preset")
        val EQ_BANDS_CSV = stringPreferencesKey("eq_bands_csv")
        val BASS_BOOST = intPreferencesKey("bass_boost")
        val VIRTUALIZER = intPreferencesKey("virtualizer")
        val SORT_OPTION = stringPreferencesKey("sort_option")
        val THEME_MODE = stringPreferencesKey("theme_mode")
        val ACCENT_PRESET = stringPreferencesKey("accent_preset")
    }

    val settingsFlow: Flow<PersistedSettings> = context.dataStore.data.map { prefs ->
        PersistedSettings(
            lastPlayedSongId = prefs[Keys.LAST_SONG_ID] ?: -1L,
            lastPlaybackPositionMs = prefs[Keys.LAST_POSITION_MS] ?: 0L,
            lastQueueIdsCsv = prefs[Keys.LAST_QUEUE_CSV] ?: "",
            shuffleEnabled = prefs[Keys.SHUFFLE] ?: false,
            repeatMode = prefs[Keys.REPEAT_MODE] ?: 0,
            playbackSpeed = prefs[Keys.PLAYBACK_SPEED] ?: 1.0f,
            playbackPitch = prefs[Keys.PLAYBACK_PITCH] ?: 1.0f,
            audioBalance = prefs[Keys.AUDIO_BALANCE] ?: 0.0f,
            masterVolume = prefs[Keys.MASTER_VOLUME] ?: 1.0f,
            gaplessPlayback = prefs[Keys.GAPLESS] ?: true,
            equalizerEnabled = prefs[Keys.EQ_ENABLED] ?: false,
            equalizerPresetIndex = prefs[Keys.EQ_PRESET] ?: 0,
            equalizerBandLevelsCsv = prefs[Keys.EQ_BANDS_CSV] ?: "",
            bassBoostStrength = prefs[Keys.BASS_BOOST] ?: 0,
            virtualizerStrength = prefs[Keys.VIRTUALIZER] ?: 0,
            sortOption = runCatching {
                SortOption.valueOf(prefs[Keys.SORT_OPTION] ?: SortOption.TITLE_ASC.name)
            }.getOrDefault(SortOption.TITLE_ASC),
            themeMode = runCatching {
                ThemeMode.valueOf(prefs[Keys.THEME_MODE] ?: ThemeMode.AMOLED_BLACK.name)
            }.getOrDefault(ThemeMode.AMOLED_BLACK),
            accentPreset = runCatching {
                AccentPreset.valueOf(prefs[Keys.ACCENT_PRESET] ?: AccentPreset.CRIMSON_RED.name)
            }.getOrDefault(AccentPreset.CRIMSON_RED)
        )
    }

    suspend fun saveLastPlaybackState(songId: Long, positionMs: Long, queueIds: List<Long>) {
        context.dataStore.edit { prefs ->
            prefs[Keys.LAST_SONG_ID] = songId
            prefs[Keys.LAST_POSITION_MS] = positionMs
            if (queueIds.isNotEmpty()) {
                prefs[Keys.LAST_QUEUE_CSV] = queueIds.take(500).joinToString(",")
            }
        }
    }

    suspend fun setShuffleAndRepeat(shuffle: Boolean, repeatMode: Int) {
        context.dataStore.edit { prefs ->
            prefs[Keys.SHUFFLE] = shuffle
            prefs[Keys.REPEAT_MODE] = repeatMode
        }
    }

    suspend fun setPlaybackSpeedAndPitch(speed: Float, pitch: Float = 1.0f) {
        context.dataStore.edit { prefs ->
            prefs[Keys.PLAYBACK_SPEED] = speed.coerceIn(0.25f, 3.0f)
            prefs[Keys.PLAYBACK_PITCH] = pitch.coerceIn(0.5f, 2.0f)
        }
    }

    suspend fun setAudioBalanceAndVolume(balance: Float, volume: Float) {
        context.dataStore.edit { prefs ->
            prefs[Keys.AUDIO_BALANCE] = balance.coerceIn(-1.0f, 1.0f)
            prefs[Keys.MASTER_VOLUME] = volume.coerceIn(0.0f, 1.0f)
        }
    }

    suspend fun setGaplessPlayback(enabled: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[Keys.GAPLESS] = enabled
        }
    }

    suspend fun saveEqualizerState(
        enabled: Boolean,
        presetIndex: Int,
        bandLevels: List<Short>,
        bassBoost: Int,
        virtualizer: Int
    ) {
        context.dataStore.edit { prefs ->
            prefs[Keys.EQ_ENABLED] = enabled
            prefs[Keys.EQ_PRESET] = presetIndex
            prefs[Keys.EQ_BANDS_CSV] = bandLevels.joinToString(",")
            prefs[Keys.BASS_BOOST] = bassBoost.coerceIn(0, 1000)
            prefs[Keys.VIRTUALIZER] = virtualizer.coerceIn(0, 1000)
        }
    }

    suspend fun setSortOption(option: SortOption) {
        context.dataStore.edit { prefs ->
            prefs[Keys.SORT_OPTION] = option.name
        }
    }

    suspend fun setThemeMode(mode: ThemeMode) {
        context.dataStore.edit { prefs ->
            prefs[Keys.THEME_MODE] = mode.name
        }
    }

    suspend fun setAccentPreset(preset: AccentPreset) {
        context.dataStore.edit { prefs ->
            prefs[Keys.ACCENT_PRESET] = preset.name
        }
    }
}
