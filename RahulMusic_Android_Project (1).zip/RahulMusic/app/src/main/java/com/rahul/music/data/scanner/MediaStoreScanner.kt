package com.rahul.music.data.scanner

import android.content.ContentUris
import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.provider.DocumentsContract
import android.provider.MediaStore
import com.rahul.music.data.local.SongEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

class MediaStoreScanner(private val context: Context) {

    companion object {
        val SUPPORTED_EXTENSIONS = setOf(
            "mp3", "flac", "wav", "aac", "m4a", "ogg", "opus",
            "wma", "aiff", "aif", "alac", "ape", "wv", "mka"
        )
    }

    /**
     * Scans all external storage volumes (Internal Storage + removable SD Cards)
     * using MediaStore.Audio.Media and resolves genres & artwork URIs.
     */
    suspend fun scanAllMediaStoreVolumes(): List<SongEntity> = withContext(Dispatchers.IO) {
        val results = LinkedHashMap<Long, SongEntity>()
        val genreMap = loadGenreMapping()

        val volumes: Set<String> = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            MediaStore.getExternalVolumeNames(context)
        } else {
            setOf("external")
        }

        val projection = mutableListOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ARTIST_ID,
            MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.ALBUM_ID,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.DATA,
            MediaStore.Audio.Media.MIME_TYPE,
            MediaStore.Audio.Media.SIZE,
            MediaStore.Audio.Media.DATE_ADDED,
            MediaStore.Audio.Media.DATE_MODIFIED,
            MediaStore.Audio.Media.TRACK
        ).apply {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                add(MediaStore.Audio.Media.GENRE)
                add(MediaStore.Audio.Media.BITRATE)
            }
        }.toTypedArray()

        val selection = "(${MediaStore.Audio.Media.IS_MUSIC} != 0 OR ${MediaStore.Audio.Media.IS_PODCAST} != 0 OR ${MediaStore.Audio.Media.DATA} != '')"

        for (volumeName in volumes) {
            val collectionUri = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                MediaStore.Audio.Media.getContentUri(volumeName)
            } else {
                MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
            }

            runCatching {
                context.contentResolver.query(
                    collectionUri,
                    projection,
                    selection,
                    null,
                    "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC"
                )?.use { cursor ->
                    val idCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                    val titleCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
                    val artistCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
                    val artistIdCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST_ID)
                    val albumCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
                    val albumIdCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID)
                    val durationCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
                    val dataCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DATA)
                    val mimeCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.MIME_TYPE)
                    val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.SIZE)
                    val dateAddedCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DATE_ADDED)
                    val dateModCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DATE_MODIFIED)
                    val trackCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TRACK)
                    val genreCol = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                        cursor.getColumnIndex(MediaStore.Audio.Media.GENRE)
                    } else -1
                    val bitrateCol = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                        cursor.getColumnIndex(MediaStore.Audio.Media.BITRATE)
                    } else -1

                    while (cursor.moveToNext()) {
                        val id = cursor.getLong(idCol)
                        val path = cursor.getString(dataCol) ?: ""
                        val mimeType = cursor.getString(mimeCol) ?: "audio/*"
                        val ext = path.substringAfterLast('.', "").lowercase()

                        if (ext.isNotEmpty() && ext !in SUPPORTED_EXTENSIONS && !mimeType.startsWith("audio/")) {
                            continue
                        }

                        val duration = cursor.getLong(durationCol)
                        // Skip tiny system ringtones/notification clips under 3 seconds
                        if (duration in 1..2999) continue

                        val rawTitle = cursor.getString(titleCol)?.trim()
                        val fallbackTitle = File(path).nameWithoutExtension.ifBlank { "Unknown Track" }
                        val title = if (rawTitle.isNullOrBlank() || rawTitle == "<unknown>") fallbackTitle else rawTitle

                        val rawArtist = cursor.getString(artistCol)?.trim()
                        val artist = if (rawArtist.isNullOrBlank() || rawArtist == "<unknown>") "Unknown Artist" else rawArtist
                        val artistId = cursor.getLong(artistIdCol)

                        val rawAlbum = cursor.getString(albumCol)?.trim()
                        val album = if (rawAlbum.isNullOrBlank() || rawAlbum == "<unknown>") "Unknown Album" else rawAlbum
                        val albumId = cursor.getLong(albumIdCol)

                        val contentUri = ContentUris.withAppendedId(collectionUri, id)
                        val albumArtUri = ContentUris.withAppendedId(
                            Uri.parse("content://media/external/audio/albumart"),
                            albumId
                        )

                        val parentFile = File(path).parentFile
                        val folderPath = parentFile?.absolutePath ?: "/Storage"
                        val folderName = parentFile?.name?.ifBlank { "Internal Storage" } ?: "Internal Storage"

                        val directGenre = if (genreCol >= 0) cursor.getString(genreCol)?.trim() else null
                        val genre = when {
                            !directGenre.isNullOrBlank() && directGenre != "<unknown>" -> directGenre
                            genreMap.containsKey(id) -> genreMap[id]!!
                            else -> "Uncategorized"
                        }

                        val bitrateBps = if (bitrateCol >= 0) cursor.getInt(bitrateCol) else 0
                        val bitrateKbps = if (bitrateBps > 0) (bitrateBps / 1000) else 320

                        results[id] = SongEntity(
                            id = id,
                            title = title,
                            artist = artist,
                            artistId = artistId,
                            album = album,
                            albumId = albumId,
                            duration = duration.coerceAtLeast(0L),
                            uriString = contentUri.toString(),
                            albumArtUriString = albumArtUri.toString(),
                            path = path,
                            folderName = folderName,
                            folderPath = folderPath,
                            genre = genre,
                            mimeType = mimeType,
                            sizeBytes = cursor.getLong(sizeCol).coerceAtLeast(0L),
                            bitrateKbps = bitrateKbps,
                            sampleRateHz = 44100,
                            dateAddedSec = cursor.getLong(dateAddedCol),
                            dateModifiedSec = cursor.getLong(dateModCol),
                            trackNumber = cursor.getInt(trackCol)
                        )
                    }
                }
            }
        }
        results.values.toList()
    }

    /**
     * Scans a user-selected Storage Access Framework (SAF) directory tree
     * for audio files on SD cards or non-indexed directories.
     */
    suspend fun scanSafDirectoryTree(treeUri: Uri): List<SongEntity> = withContext(Dispatchers.IO) {
        val discovered = mutableListOf<SongEntity>()
        val rootDocId = DocumentsContract.getTreeDocumentId(treeUri)
        val folderLabel = rootDocId.substringAfterLast(':').substringAfterLast('/').ifBlank { "SAF Folder" }

        fun traverseDocument(docId: String, folderName: String) {
            val childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, docId)
            val projection = arrayOf(
                DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                DocumentsContract.Document.COLUMN_MIME_TYPE,
                DocumentsContract.Document.COLUMN_SIZE,
                DocumentsContract.Document.COLUMN_LAST_MODIFIED
            )
            runCatching {
                context.contentResolver.query(childrenUri, projection, null, null, null)?.use { cursor ->
                    val idCol = cursor.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_DOCUMENT_ID)
                    val nameCol = cursor.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_DISPLAY_NAME)
                    val mimeCol = cursor.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_MIME_TYPE)
                    val sizeCol = cursor.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_SIZE)
                    val modCol = cursor.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_LAST_MODIFIED)

                    while (cursor.moveToNext()) {
                        val childId = cursor.getString(idCol)
                        val displayName = cursor.getString(nameCol) ?: "Audio"
                        val mimeType = cursor.getString(mimeCol) ?: ""

                        if (mimeType == DocumentsContract.Document.MIME_TYPE_DIR) {
                            traverseDocument(childId, displayName)
                        } else {
                            val ext = displayName.substringAfterLast('.', "").lowercase()
                            if (ext in SUPPORTED_EXTENSIONS || mimeType.startsWith("audio/")) {
                                val fileUri = DocumentsContract.buildDocumentUriUsingTree(treeUri, childId)
                                val size = cursor.getLong(sizeCol)
                                val lastModMs = cursor.getLong(modCol)
                                val syntheticId = (fileUri.toString().hashCode().toLong() and 0x7FFFFFFFL) + 1_000_000_000L

                                val retriever = MediaMetadataRetriever()
                                var title = displayName.substringBeforeLast('.')
                                var artist = "Unknown Artist"
                                var album = folderName
                                var genre = "Uncategorized"
                                var durationMs = 0L
                                var bitrateKbps = 320

                                runCatching {
                                    retriever.setDataSource(context, fileUri)
                                    retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE)?.takeIf { it.isNotBlank() }?.let { title = it }
                                    retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST)?.takeIf { it.isNotBlank() }?.let { artist = it }
                                    retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUM)?.takeIf { it.isNotBlank() }?.let { album = it }
                                    retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_GENRE)?.takeIf { it.isNotBlank() }?.let { genre = it }
                                    durationMs = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
                                    bitrateKbps = (retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_BITRATE)?.toIntOrNull() ?: 320000) / 1000
                                }
                                runCatching { retriever.release() }

                                discovered.add(
                                    SongEntity(
                                        id = syntheticId,
                                        title = title,
                                        artist = artist,
                                        artistId = artist.hashCode().toLong(),
                                        album = album,
                                        albumId = album.hashCode().toLong(),
                                        duration = durationMs,
                                        uriString = fileUri.toString(),
                                        albumArtUriString = null,
                                        path = fileUri.toString(),
                                        folderName = folderName,
                                        folderPath = "SAF:$folderName",
                                        genre = genre,
                                        mimeType = mimeType.ifBlank { "audio/$ext" },
                                        sizeBytes = size,
                                        bitrateKbps = bitrateKbps,
                                        sampleRateHz = 44100,
                                        dateAddedSec = lastModMs / 1000L,
                                        dateModifiedSec = lastModMs / 1000L,
                                        trackNumber = 0
                                    )
                                )
                            }
                        }
                    }
                }
            }
        }

        traverseDocument(rootDocId, folderLabel)
        discovered
    }

    private fun loadGenreMapping(): Map<Long, String> {
        val map = HashMap<Long, String>()
        runCatching {
            val genreProjection = arrayOf(MediaStore.Audio.Genres._ID, MediaStore.Audio.Genres.NAME)
            context.contentResolver.query(
                MediaStore.Audio.Genres.EXTERNAL_CONTENT_URI,
                genreProjection,
                null,
                null,
                null
            )?.use { genreCursor ->
                val genreIdCol = genreCursor.getColumnIndexOrThrow(MediaStore.Audio.Genres._ID)
                val genreNameCol = genreCursor.getColumnIndexOrThrow(MediaStore.Audio.Genres.NAME)
                while (genreCursor.moveToNext()) {
                    val genreId = genreCursor.getLong(genreIdCol)
                    val genreName = genreCursor.getString(genreNameCol)?.trim() ?: continue
                    if (genreName.isBlank() || genreName == "<unknown>") continue

                    val membersUri = MediaStore.Audio.Genres.Members.getContentUri("external", genreId)
                    context.contentResolver.query(
                        membersUri,
                        arrayOf(MediaStore.Audio.Genres.Members.AUDIO_ID),
                        null,
                        null,
                        null
                    )?.use { membersCursor ->
                        val audioIdCol = membersCursor.getColumnIndexOrThrow(MediaStore.Audio.Genres.Members.AUDIO_ID)
                        while (membersCursor.moveToNext()) {
                            map[membersCursor.getLong(audioIdCol)] = genreName
                        }
                    }
                }
            }
        }
        return map
    }
}
